<?php

return [
    'success_save_form'=>'اطلاعات به درستی ذخیره شدند',
];