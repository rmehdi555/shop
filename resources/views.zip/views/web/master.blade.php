@include('web.section.head')
@include('web.section.header')
@yield('content')
@include('web.section.footer')
@include('web.section.script')

