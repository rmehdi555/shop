@include('web.section.head')
@include('web.section.header')
@include('web.section.product-side')
@yield('content')
@include('web.section.footer')
@include('web.section.script')

