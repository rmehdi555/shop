

<!-- JS Part Start-->
<script type="text/javascript" src="{{asset('web/2021/js/jquery-3.3.1.min.js')}}"></script>
<script type="text/javascript" src="{{asset('web/2021/js/bootstrap-rtl.js')}}"></script>
<script type="text/javascript" src="{{asset('web/2021/js/jquery.magnific-popup.min.js')}}"></script>
<script type="text/javascript" src="{{asset('web/2021/js/jquery.slicknav.js')}}"></script>
<script type="text/javascript" src="{{asset('web/2021/js/owl.carousel.min.js')}}"></script>
<script type="text/javascript" src="{{asset('web/2021/js/main-v-1-2-1.js?v='.time())}}"></script>

</body>
</html>