
<?php $__env->startSection('content'); ?>
    <div class="main-inner-banner">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="main-inner-banner-cont">
                        <div class="main-inner-banner-c-title">
                            <ul class="main-breadcrumb">
                                <li><a href="<?php echo e(route('web.home')); ?>"><?php echo e(__('web/public.home_page')); ?></a></li>
                                
                            </ul>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <section class="bu-inner-main">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="alert alert-info m-1">

                        <p class="p-1 text-justify">
                            ثبت نام با موفقیت انجام شد
                            <br>
                            کد ثبت نامی شما در مسابقه مالک زمان
<?php echo e($mosabegheMalekeZaman->id); ?>

                            میباشد
                            <br>
                            کد ملی و کد پیگیری جهت ادامه مسابقه مورد نیاز میباشند

                        </p>

                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Start: Inner main -->





<?php $__env->stopSection(); ?>



<?php echo $__env->make('web.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Mr Rezaei\Desktop\noor\resources\views/web/pages/mosabeghe-level-2.blade.php ENDPATH**/ ?>