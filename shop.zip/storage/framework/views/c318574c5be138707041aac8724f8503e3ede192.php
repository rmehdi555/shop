
<?php $__env->startSection('content'); ?>
    <div id="main-content">
        <div class="container-fluid">
            
            
            
            
            
            
            
            
            
            
            
            




            <div class="row clearfix">
                <div class="col-md-12">
                    <div class="card">
                        <div class="header">
                            <h2><?php echo e(__('admin/public.create_menu')); ?></h2>
                        </div>
                        <div class="body">
                            <form id="basic-form" action="<?php echo e(route('menus.store')); ?>" method="post" enctype="multipart/form-data" novalidate>
                                <?php echo csrf_field(); ?>
                                <?php echo $__env->make('admin.section.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <?php
                                $allLang=\App\Providers\MyProvider::get_languages();
                                foreach ($allLang as $kay => $value)
                                {
                                ?>
                                <div class="form-group">
                                    <label><?php echo e(__('admin/public.title')); ?> (<?php echo e($kay); ?>):</label>
                                    <input type="text" name="title_<?php echo e($kay); ?>" class="form-control" value="<?php echo e(old('title_'.$kay)); ?>" required>
                                </div>
                                <?php
                                }
                                ?>
                                <div class="form-group col-lg-4 col-md-12">
                                    <label><?php echo e(__('admin/public.menu_categories_id')); ?> :</label>
                                    <div class="multiselect_div">
                                        <select id="single-selection" name="menu_categories_id" class="multiselect multiselect-custom" >
                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($category->id); ?>"><?php echo e(\App\Providers\MyProvider::_text($category->title)); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="form-group col-lg-4 col-md-12">
                                    <label><?php echo e(__('admin/public.parent_id')); ?> :</label>
                                    <div class="multiselect_div">
                                        <select id="single-selection" name="parent_id" class="multiselect multiselect-custom" >
                                            <option value="0"><?php echo e(__('admin/public.base_parent_id')); ?></option>
                                            <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($menu->id); ?>"><?php echo e(\App\Providers\MyProvider::_text($menu->title)); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label><?php echo e(__('admin/public.link')); ?> :</label>
                                    <input type="text" name="link" class="form-control" value="" required>
                                </div>
                                <div class="form-group">
                                    <label><?php echo e(__('admin/public.icon')); ?> :</label>
                                    <input type="text" name="icon" class="form-control" value="i" required>
                                </div>

                                <div class="form-group">
                                    <label><?php echo e(__('admin/public.priority')); ?> :</label>
                                    <input type="number" name="priority" class="form-control" value="<?php echo e(old('priority')); ?>" required>
                                </div>

                                <div class="form-group col-lg-4 col-md-12">
                                    <label><?php echo e(__('admin/public.status')); ?> :</label>
                                    <div class="multiselect_div">
                                        <select id="single-selection" name="status" class="multiselect multiselect-custom" >
                                            <option value="1"><?php echo e(__('admin/public.active')); ?></option>
                                            <option value="0"><?php echo e(__('admin/public.inactive')); ?></option>
                                        </select>
                                    </div>
                                </div>


                                <br>
                                <button type="submit" class="btn btn-primary"><?php echo e(__('admin/public.submit')); ?></button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Mr Rezaei\Desktop\noor\resources\views/admin/menus/create.blade.php ENDPATH**/ ?>