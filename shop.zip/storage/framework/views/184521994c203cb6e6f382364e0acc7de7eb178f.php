
<?php $__env->startSection('content'); ?>
    <div id="main-content">
        <div class="container-fluid">
            
            
            
            
            
            
            
            
            
            
            
            




            <div class="row clearfix">
                <div class="col-md-12">
                    <div class="card">
                        <div class="header">
                            <h2><?php echo e(__('admin/public.edit')); ?></h2>
                        </div>
                        <div class="body">
                            <form id="basic-form" action="<?php echo e(route('siteDetails.update',$siteDetails->id)); ?>" method="POST" enctype="multipart/form-data" novalidate>
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PATCH'); ?>
                                <?php echo $__env->make('admin.section.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <div class="form-group">
                                    <label><?php echo e(__('admin/public.title')); ?> :</label>
                                    <input type="text" name="title" class="form-control" value="<?php echo e($siteDetails->title); ?>" required>
                                </div>
                                <div class="form-group">
                                    <label><?php echo e(__('admin/public.key')); ?> :</label>
                                    <input type="text" name="key" class="form-control" value="<?php echo e($siteDetails->key); ?>" required>
                                </div>

                                <?php
                                $allLang=\App\Providers\MyProvider::get_languages();
                                foreach ($allLang as $kay => $value)
                                {
                                ?>
                                    <div class="form-group">
                                        <label><?php echo e(__('admin/public.value')); ?> (<?php echo e($kay); ?>) :</label>
                                        <textarea name="value_<?php echo e($kay); ?>" id="ckeditor" class="form-control" rows="5" cols="30" required><?php echo e(\App\Providers\MyProvider::_text($siteDetails->value,$kay)); ?></textarea>
                                    </div>
                                <?php
                                }
                                ?>
                                <div class="form-group">
                                    <label><?php echo e(__('admin/public.images')); ?> :</label>
                                    <input type="file" name="images" class="form-control" value="<?php echo e(old('images')); ?>" >
                                </div>
                                <?php if($siteDetails->type=="image" and $siteDetails->images!=[]): ?>

                                    <div class="media">
                                        <img class="media-object " src="<?php echo e($siteDetails->images["thumb"]); ?>" alt="">
                                        
                                        
                                        
                                        
                                        
                                    </div>

                                <?php endif; ?>



                                <div class="form-group col-lg-4 col-md-12">
                                    <label><?php echo e(__('admin/public.status')); ?> :</label>
                                    <div class="multiselect_div">
                                        <select id="single-selection" name="status" class="multiselect multiselect-custom" >
                                            <option value="0"><?php echo e(__('admin/public.inactive')); ?></option>
                                            <option value="1" <?php echo e($siteDetails->status?"selected":""); ?>><?php echo e(__('admin/public.active')); ?></option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group col-lg-4 col-md-12">
                                    <label><?php echo e(__('admin/public.type')); ?> :</label>
                                    <div class="multiselect_div">
                                        <select id="single-selection" name="type" class="multiselect multiselect-custom" >
                                            <option value="text"><?php echo e(__('admin/public.text')); ?></option>
                                            <option value="image" <?php echo e(($siteDetails->type=="image")?"selected":""); ?>><?php echo e(__('admin/public.image')); ?></option>
                                        </select>
                                    </div>
                                </div>


                                <br>
                                <button type="submit" class="btn btn-primary"><?php echo e(__('admin/public.submit')); ?></button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rmehdi555\Desktop\noor\resources\views/admin/site-details/edit.blade.php ENDPATH**/ ?>