
<?php $__env->startSection('content'); ?>
    <div id="main-content">
        <div class="container-fluid">
            
            
            
            
            
            
            
            
            
            
            
            




            <div class="row clearfix">
                <div class="col-md-12">
                    <div class="card">
                        <div class="header">
                            <h2><?php echo e(__('admin/public.create_product')); ?></h2>
                        </div>
                        <div class="body">
                            <form id="basic-form" action="<?php echo e(route('news.store')); ?>" method="post" enctype="multipart/form-data" novalidate>
                                <?php echo csrf_field(); ?>
                                <?php echo $__env->make('admin.section.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <?php
                                $allLang=\App\Providers\MyProvider::get_languages();
                                foreach ($allLang as $kay => $value)
                                {
                                ?>
                                <div class="form-group">
                                    <label><?php echo e(__('admin/public.title')); ?> (<?php echo e($kay); ?>):</label>
                                    <input type="text" name="title_<?php echo e($kay); ?>" class="form-control" value="<?php echo e(old('title_'.$kay)); ?>" required>
                                </div>
                                <?php
                                }
                                $allLang=\App\Providers\MyProvider::get_languages();
                                foreach ($allLang as $kay => $value)
                                {
                                ?>
                                <div class="form-group">
                                    <label><?php echo e(__('admin/public.description')); ?> (<?php echo e($kay); ?>):</label>
                                    <textarea name="description_<?php echo e($kay); ?>" id="description_<?php echo e($kay); ?>" class="form-control" rows="5" cols="30" required><?php echo e(old('description_'.$kay)); ?></textarea>

                                </div>
                                <?php
                                }
                                $allLang=\App\Providers\MyProvider::get_languages();
                                foreach ($allLang as $kay => $value)
                                {
                                ?>
                                <div class="form-group">
                                    <label><?php echo e(__('admin/public.body')); ?> (<?php echo e($kay); ?>):</label>
                                    <textarea name="body_<?php echo e($kay); ?>" class="form-control ckeditor" rows="5" cols="30" required><?php echo e(old('body_'.$kay)); ?></textarea>

                                </div>
                                <?php
                                }
                                ?>
                                <div class="form-group col-lg-4 col-md-12">
                                    <label><?php echo e(__('admin/public.news_categories_id')); ?> :</label>
                                    <div class="multiselect_div">
                                        <select id="single-selection" name="news_categories_id" class="multiselect multiselect-custom" >
                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($category->id); ?>"><?php echo e(\App\Providers\MyProvider::_text($category->title)); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label><?php echo e(__('admin/public.images')); ?> :</label>
                                    <input type="file" name="images" class="form-control" value="<?php echo e(old('images')); ?>" required>
                                </div>
                                <div class="form-group">
                                    <label><?php echo e(__('admin/public.tags')); ?> :</label>
                                    <input type="text" name="tags" class="form-control" value="<?php echo e(old('tags')); ?>" required>
                                </div>
                                <div class="form-group">
                                    <label><?php echo e(__('admin/public.priority')); ?> :</label>
                                    <input type="number" name="priority" class="form-control" value="<?php echo e(old('priority')); ?>" required>
                                </div>

                                <div class="form-group col-lg-4 col-md-12">
                                    <label><?php echo e(__('admin/public.status')); ?> :</label>
                                    <div class="multiselect_div">
                                        <select id="single-selection" name="status" class="multiselect multiselect-custom" >
                                            <option value="1"><?php echo e(__('admin/public.active')); ?></option>
                                            <option value="0"><?php echo e(__('admin/public.inactive')); ?></option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group col-lg-4 col-md-12">
                                    <label><?php echo e(__('admin/public.type')); ?> :</label>
                                    <div class="multiselect_div">
                                        <select id="single-selection" name="type" class="multiselect multiselect-custom" >
                                            <option value="normal"><?php echo e(__('admin/public.normal')); ?></option>
                                            <option value="special"><?php echo e(__('admin/public.special')); ?></option>
                                            <option value="offer"><?php echo e(__('admin/public.offer')); ?></option>
                                        </select>
                                    </div>
                                </div>


                                <br>
                                <button type="submit" class="btn btn-primary"><?php echo e(__('admin/public.submit')); ?></button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Mr Rezaei\Desktop\noor\resources\views/admin/news/create.blade.php ENDPATH**/ ?>