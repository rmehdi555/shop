
<?php $__env->startSection('content'); ?>
    <div id="main-content">
        <div class="container-fluid">
            <div class="block-header">
                <div class="row">
                    <div class="col-lg-5 col-md-8 col-sm-12">
                        <h2><?php echo e(__('admin/public.contact_us_list')); ?></h2>
                    </div>
                    <div class="col-lg-7 col-md-4 col-sm-12 text-right">
                        
                            
                        
                    </div>
                </div>
            </div>




            <div class="row clearfix">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="header">
                            <h2><?php echo e(__('admin/public.contact_us_list')); ?></h2>
                        </div>
                        <div class="body">

                            <div class="table-responsive">
                                <table class="table table-bordered table-hover js-basic-example dataTable table-custom">
                                    <thead>
                                    <tr>
                                        <th><?php echo e(__('admin/public.created_at')); ?></th>
                                        <th><?php echo e(__('admin/public.name')); ?></th>
                                        <th><?php echo e(__('admin/public.family')); ?></th>
                                        <th><?php echo e(__('admin/public.phone')); ?></th>
                                        <th><?php echo e(__('admin/public.email')); ?></th>
                                        <th><?php echo e(__('admin/public.body')); ?></th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $allContactUs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="gradeA">
                                            <td><?php echo e(\App\Providers\MyProvider::show_date($item->created_at,'Y-n-j')); ?></td>
                                            <td><?php echo e($item->name); ?></td>
                                            <td><?php echo e($item->family); ?></td>
                                            <td><?php echo e($item->phone); ?></td>
                                            <td><?php echo e($item->email); ?></td>
                                            <td><?php echo e($item->body); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                    </tbody>
                                    <tfoot>
                                    <tr>
                                        <th><?php echo e(__('admin/public.created_at')); ?></th>
                                        <th><?php echo e(__('admin/public.name')); ?></th>
                                        <th><?php echo e(__('admin/public.family')); ?></th>
                                        <th><?php echo e(__('admin/public.phone')); ?></th>
                                        <th><?php echo e(__('admin/public.email')); ?></th>
                                        <th><?php echo e(__('admin/public.body')); ?></th>
                                    </tr>
                                    </tfoot>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Mr Rezaei\Desktop\noor\resources\views/admin/contact-us/index.blade.php ENDPATH**/ ?>