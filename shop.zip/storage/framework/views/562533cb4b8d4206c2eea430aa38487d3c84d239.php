
<body>
<?php echo $__env->make('sweet::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Start: Main Wrapper -->
<div class="bu-wrapper" >

    <div class="bu-overlay"></div>


    <header class="main-header noPrint">
        <div class="container">
            <div class="row">
                <div class="col-md-12">

                    <div class="main-header-cont">
                        <div class="col-md-4">
                            <a href="<?php echo e(route('web.home')); ?>" title="" rel="home" class="main-logo">
                                <h2 style="color: white ; width: auto"><?php echo e(\App\Providers\MyProvider::_text($siteDetailsProvider["site_name"]->value)); ?></h2>
                                
                            </a>

                        </div>
                        <div class="col-md-4">

                            <div class="s-logo">
                                <img src="<?php echo e($siteDetailsProvider["image_header"]->images["images"]["original"]); ?>" alt="<?php echo e(\App\Providers\MyProvider::_text($siteDetailsProvider["site_name"]->value)); ?>">
                            </div>
                        </div>
                        <div class=" col-md-4">
                        <div class="main-header-tc-search">
                            <div class="main-header-tc-topheader">
                                <div class="main-header-tct-item main-date">
                                    <span class="main-header-tcti-date"><?php use Hekmatinasser\Verta\Verta;$v=Verta::now();    echo($v->formatWord('l').' '.$v->format('d').' '.$v->formatWord('F').' '.$v->format('Y'));?></span>
                                </div>
                                <div class="main-header-tct-item">
                                    <ul class="main-header-trs-list">
                                        
                                        <li><a href="<?php echo e(\App\Providers\MyProvider::_text($siteDetailsProvider["instagram"]->value)); ?>"><i class="fab fa-instagram"></i></a></li>
                                    </ul>
                                </div>

                            </div>
                            <form class="main-header-tc-search-form" method="get" >
                                <i class="far fa-search main-header-tc-search-icon" id="main-search-btn"></i>
                                <div class="main-header-tc-search-box" id="main-search-box">
                                    <div class="main-header-tc-search-close" id="main-search-close"><i class="fal fa-times"></i></div>
                                    <input class="form-control main-header-tc-search-input main-search-placeholder" name="s" placeholder="جستجو کنید..." id="main-search-input" autocomplete="off">
                                    <button type="submit" class="main-header-tc-search-btn"><i class="far fa-search"></i></button>
                                </div>
                            </form>
                        </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <div class="main-header-nav-cont noPrint">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="main-menu navbar-offcanvas navbar-offcanvas-touch" id="js-bootstrap-offcanvas">
                        <ul class="main-menu-list">
                            <?php $__currentLoopData = $webMenusHeaderProvider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($menu->parent_id==0 AND isset($menu->children[0]) AND $menu->children!=[]): ?>
                                    <li class=""><a href="<?php echo e($menu->link); ?>" id="dropdownMenuButton" data-toggle="dropdown"><?php echo e(\App\Providers\MyProvider::_text($menu->title)); ?> <i class="fa fa-caret-down main-menu-arrow"></i></a>
                                        <?php if(isset($menu->children[0]) and $menu->children!=[]): ?>
                                            <ul class="main-menu-dropmenu dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuButton">
                                                 <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.web-show-menus','data' => ['menus' => $menu->children]]); ?>
<?php $component->withName('web-show-menus'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['menus' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($menu->children)]); ?>
                                                 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                                            </ul>
                                        <?php endif; ?>
                                    </li>
                                <?php elseif($menu->parent_id==0): ?>
                                    <li class=""><a href="<?php echo e($menu->link); ?>"><?php echo e(\App\Providers\MyProvider::_text($menu->title)); ?></a></li>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <?php if(auth()->check()): ?>
                                    <li class=""><a href="<?php echo e(route('logout')); ?>"><?php echo e(__('web/public.btn_logout')); ?></a></li>
                                <?php else: ?>
                                    
                                <?php endif; ?>
                        </ul>
                    </div>
                    <button class="navbar-toggler offcanvas-toggle" type="button" data-toggle="offcanvas" data-target="#js-bootstrap-offcanvas" aria-controls="navbarTogglerDemo03" aria-expanded="false" aria-label="Toggle navigation">
                        <a class="menu-btn menu-link" id="nav-icon">
                            <span></span>
                            <span></span>
                            <span></span>
                        </a>
                    </button>
                </div>
            </div>
        </div>
    </div>



<?php /**PATH C:\Users\Mr Rezaei\Desktop\noor\resources\views/web/section/header.blade.php ENDPATH**/ ?>