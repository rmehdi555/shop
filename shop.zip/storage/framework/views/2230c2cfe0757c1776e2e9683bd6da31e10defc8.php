
<?php $__env->startSection('content'); ?>

    <section class="bu-inner-main">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="alert alert-info m-1">
                        <p class="p-1 text-justify">قرآن آموز گرامی
                            <?php echo e($user->student->name); ?>  <?php echo e($user->student->family); ?>

                            احراز هویت شماره همراه شما به درستی انجام شده و برای ادامه ثبت نام لیست رشته های انتخابی را
                            مشاهده و پرداخت نمایید .
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="bu-inner-main">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="alert alert-success m-1">
                        <p class="p-1 text-justify"> درصورت عضو نهاد خاص بودن هزینه دوره ها با تخفیف درنظر گرفته خواهد شد
                            ، که لازم است تیک گزینه عضو نهاد های خاص را کلیک نموده و مدرک مورد نظر را بارگذاری نمایید
                            تا توسط کارشناس های ما بررسی و نتیجه را اعلام نماییند.

                        <br>
                            نهاد هایی که شامل تخفیف خواهند شد :
                         <br>
                            - تحت پوشش کمیته امداد امام خمینی
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Start: Inner main -->
    <section class="bu-inner-main">
        <div class="container">

            <div class="row">
                <p class="bu-margin-bottom-30"><?php echo e(__('web/public.student_field_select')); ?> : </p>
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th><?php echo e(__('web/public.title_field')); ?></th>
                            <th><?php echo e(__('web/public.price')); ?>(<?php echo e(__('web/public.currency_name_IRR')); ?>)</th>
                            
                        </tr>
                        </thead>
                        <tbody>
                        <?php $i=1; $finalPrice=0;?>
                        <?php $__currentLoopData = $user->student->studentsFields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($i); ?></td>
                                <td><?php echo e($item->title); ?></td>
                                <td><?php echo e(number_format($item->price)); ?></td>
                                
                                
                                
                            </tr>
                            <?php $i++; $finalPrice+=$item->price; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr class="table-primary">
                            <td colspan='2'><?php echo e(__('web/public.price_final')); ?>

                                (<?php echo e(__('web/public.currency_name_IRR')); ?>) :
                            </td>
                            <td colspan='2'><?php echo e(number_format($finalPrice)); ?></td>
                        </tr>
                        </tbody>
                    </table>
                </div>
            </div>
                <br><br>

            <form class="form-horizontal" id="form-level-1-save" method="POST"
                  action="<?php echo e(route('student.level.1.save')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                <div class="row">
                    <div class="col-md-12">
                        <div class="contact-form__two">
                            <input id="contract-checkbox"
                                   type="checkbox">عضو نهاد های خاص هستم
                        </div>
                        <div class="comment-submit-btn text-center contract-button">
                            <div class="custom-file mb-3 col-6">
                                <input type="file" class="custom-file-input" id="customFile" name="filename" required>
                                <label class="custom-file-label" for="customFile">مدرک عضو نهاد را بارگذاری نمایید</label>
                            </div>
                            <button type="submit" class="btn btn-primary"><?php echo e(__('web/public.submit')); ?></button>
                        </div>
                    </div>
                </div>
            </form>
                <br><br>

                <div class="row">
                    <div class="col-md-12">
                        <div class="d-flex justify-content-center mb-2 ">
                            <div class="p-2 contract-div-hide">
                                <a href="<?php echo e(route('student.payment.index')); ?>"
                                        class="btn btn-primary"><?php echo e(__('web/public.btn_payment')); ?></a>
                            </div>
                        </div>
                    </div>
                </div>





        </div>
    </section>
    <!-- Start: Inner main -->





<?php $__env->stopSection(); ?>



<?php echo $__env->make('student.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Mr Rezaei\Desktop\noor\resources\views/student/pages/status-1.blade.php ENDPATH**/ ?>