<body class="theme-blue rtl">

<!-- Page Loader -->

    
        
        
    

<!-- Overlay For Sidebars -->
<div class="overlay" style="display: none;"></div>

<div id="wrapper">

    <nav class="navbar navbar-fixed-top">
        <div class="container-fluid">

            <div class="navbar-brand">
                <a href="<?php echo e(route('admin.panel')); ?>">
                    
                    <span class="name"><?php echo e(__('admin/public.panel_name')); ?></span>
                </a>
            </div>

            <div class="navbar-right">
                <ul class="list-unstyled clearfix mb-0">
                    <li>
                        <div class="navbar-btn btn-toggle-show">
                            <button type="button" class="btn-toggle-offcanvas"><i class="lnr lnr-menu fa fa-bars"></i></button>
                        </div>
                        <a href="javascript:void(0);" class="btn-toggle-fullwidth btn-toggle-hide"><i class="fa fa-bars"></i></a>
                    </li>
                    <li>
                        
                            
                            
                        
                    </li>
                    <li>
                        <div id="navbar-menu">
                            <ul class="nav navbar-nav">
                                
                                    
                                
                                
                                    
                                
                                
                                    
                                        
                                        
                                    
                                    
                                        
                                        
                                            
                                                
                                                    
                                                        
                                                    
                                                    
                                                        
                                                        
                                                    
                                                
                                            
                                        
                                        
                                            
                                                
                                                    
                                                        
                                                    
                                                    
                                                        
                                                        
                                                    
                                                
                                            
                                        
                                        
                                            
                                                
                                                    
                                                        
                                                    
                                                    
                                                        
                                                        
                                                    
                                                
                                            
                                        
                                        
                                            
                                                
                                                    
                                                        
                                                    
                                                    
                                                        
                                                        
                                                    
                                                
                                            
                                        
                                        
                                    
                                
                                
                                    
                                    
                                        
                                        
                                            
                                                
                                                    
                                                        
                                                        
                                                            
                                                        
                                                    
                                                
                                                
                                                    
                                                        
                                                        
                                                            
                                                        
                                                    
                                                
                                                
                                                    
                                                        
                                                        
                                                            
                                                        
                                                    
                                                
                                                
                                                    
                                                        
                                                        
                                                            
                                                        
                                                    
                                                
                                                
                                                    
                                                        
                                                        
                                                            
                                                        
                                                    
                                                
                                            
                                        
                                        
                                    
                                
                                
                                    
                                    
                                        
                                        
                                        
                                        
                                    
                                
                                
                                    
                                        
                                    
                                    
                                        
                                            
                                                
                                            
                                            
                                                
                                                
                                            
                                        
                                        
                                            
                                                
                                                
                                                
                                                
                                                
                                            
                                        
                                    
                                
                                
                                    
                                
                            </ul>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </nav><?php /**PATH C:\Users\Mr Rezaei\Desktop\shop\resources\views/admin/section/header.blade.php ENDPATH**/ ?>