
<?php $__env->startSection('content'); ?>

    <section class="bu-inner-main">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="alert alert-info m-1">
                        <p class="p-1 text-justify">معلم گرامی
                            <?php echo e($user->teacher->name); ?>  <?php echo e($user->teacher->family); ?>

                  مشخصات وارد شده را با دقت مطالعه سپس تایید نمایید  .
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="bu-inner-main">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="alert alert-success m-1">
                        <p class="p-1 text-justify">
                            اطلاعات وارد شده را با دقت مطالعه  و درصورت نیاز ویرایش نماید سپس دکمه بعدی را انخاب کنید ، لازم به ذکر میباشد صحت اطلاعات شما در این مرحله تایید نهایی میشوند .
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="bu-inner-main">
        <div class="container">
            <form class="form-horizontal" id="form-level-1-save" method="POST"
                  action="<?php echo e(route('teacher.level.2.save')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php if(count($errors) > 0): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <div class="row">
                    <div class="col-md-6 padding-top-15">
                        <label class="col-md-6 col-sm-6 control-label" for="name"><?php echo e(__('web/public.sex')); ?>

                            : <span class="required">*</span></label>
                        <div class="col-md-12 col-sm-10" >
                            <label class="radio-inline" style="padding: 10px 40px 10px">
                                <input type="radio" name="sex"
                                       value="male" <?php if($user->teacher->sex=="male"): ?> checked <?php endif; ?>
                                ><?php echo e(__('web/public.male')); ?>

                            </label>
                            <label class="radio-inline">
                                <input type="radio"
                                       name="sex"
                                       value="female" <?php if($user->teacher->sex=="female"): ?> checked <?php endif; ?>><?php echo e(__('web/public.female')); ?>

                            </label>
                            <?php $__errorArgs = ['sex'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-md-6 padding-top-15">

                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 padding-top-15">
                        <label class="col-md-6 col-sm-6 control-label" for="name"><?php echo e(__('web/public.name')); ?>

                            : <span class="required">*</span></label>
                        <div class="col-md-12 col-sm-10">
                            <input type="text" name="name" id="name" value="<?php echo e($user->teacher->name); ?>"
                                   class="form-control  <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required/>
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-md-6 padding-top-15">
                        <label class="col-md-6 col-sm-6 control-label"
                               for="family"><?php echo e(__('web/public.family')); ?> : <span
                                    class="required">*</span></label>
                        <div class="col-md-12 col-sm-10">
                            <input type="text" name="family" id="family" value="<?php echo e($user->teacher->family); ?>"
                                   class="form-control  <?php $__errorArgs = ['family'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required/>
                            <?php $__errorArgs = ['family'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 padding-top-15">
                        <label class="col-md-6 col-sm-6 control-label"
                               for="f_name"><?php echo e(__('web/public.f_name')); ?> : <span
                                    class="required">*</span></label>
                        <div class="col-md-12 col-sm-10">
                            <input type="text" name="f_name" id="f_name" value="<?php echo e($user->teacher->f_name); ?>"
                                   class="form-control  <?php $__errorArgs = ['f_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"/>
                            <?php $__errorArgs = ['f_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-md-6 padding-top-15">
                        <label class="col-md-6 col-sm-6 control-label"
                               for="sh_number"><?php echo e(__('web/public.sh_number')); ?> : <span
                                    class="required">*</span></label>
                        <div class="col-md-12 col-sm-10">
                            <input type="text" name="sh_number" id="sh_number" value="<?php echo e($user->teacher->sh_number); ?>"
                                   id="input-name"
                                   class="form-control  <?php $__errorArgs = ['sh_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required/>
                            <?php $__errorArgs = ['sh_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 padding-top-15">
                        <label class="col-md-6 col-sm-6 control-label"
                               for="meli_number"><?php echo e(__('web/public.meli_number')); ?> : <span
                                    class="required">*</span> </label>
                        <div class="col-md-12 col-sm-10">
                            <input type="number" pattern="[0-9]{10}" name="meli_number" id="meli_number"
                                   value="<?php echo e($user->teacher->meli_number); ?>"
                                   class="form-control  <?php $__errorArgs = ['meli_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   required disabled/>
                            <span> (<?php echo e(__('web/public.meli_number_help_2')); ?>)</span>
                            <?php $__errorArgs = ['meli_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-md-6 padding-top-15">
                        <label class="col-md-6 col-sm-6 control-label"
                               for="sh_sodor"><?php echo e(__('web/public.sh_sodor')); ?> : <span
                                    class="required">*</span></label>
                        <div class="col-md-12 col-sm-10">
                            <input type="text" name="sh_sodor" id="sh_sodor" value="<?php echo e($user->teacher->sh_sodor); ?>"
                                   id="input-name"
                                   class="form-control  <?php $__errorArgs = ['sh_sodor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required/>
                            <?php $__errorArgs = ['sh_sodor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 padding-top-15">
                        <label class="col-md-6 col-sm-6 control-label"
                               for="tavalod_date"><?php echo e(__('web/public.tavalod_date')); ?> : <span
                                    class="required">*</span></label>
                        <div class="col-md-12 col-sm-12">
                            <div class='form-inline row'>
                                <?php
                                $tavalod_date=explode("-",$user->teacher->tavalod_date);
                                $user->teacher->tavalod_date_d=$tavalod_date[2];
                                $user->teacher->tavalod_date_m=$tavalod_date[1];
                                $user->teacher->tavalod_date_y=$tavalod_date[0];

                                ?>

                                <div class='form-group col-sm-4'>
                                    <select name='tavalod_date_d' class='form-control' required>
                                        <option selected
                                                disabled><?php echo e(__('web/public.tavalod_date_d')); ?></option>
                                        <?php for($i = 1; $i < 32; $i++): ?>
                                            <option value="<?php echo e($i); ?>" <?php if($user->teacher->tavalod_date_d==$i) echo "selected"; ?>><?php echo e($i); ?></option>
                                        <?php endfor; ?>
                                    </select>
                                </div>
                                <div class='form-group col-sm-4'>
                                    <select name='tavalod_date_m' class='form-control' required>
                                        <option selected
                                                disabled><?php echo e(__('web/public.tavalod_date_m')); ?></option>
                                        <?php for($i = 1; $i < 13; $i++): ?>
                                            <option value="<?php echo e($i); ?>" <?php if($user->teacher->tavalod_date_m==$i) echo "selected"; ?>><?php echo e($i); ?></option>
                                        <?php endfor; ?>
                                    </select>
                                </div>
                                <div class='form-group col-sm-4'>
                                    <select name='tavalod_date_y' class='form-control' required>
                                        <option selected
                                                disabled><?php echo e(__('web/public.tavalod_date_y')); ?></option>
                                        <?php for($i = 1400; $i > 1295; $i--): ?>
                                            <option value="<?php echo e($i); ?>" <?php if($user->teacher->tavalod_date_y==$i) echo "selected"; ?>><?php echo e($i); ?></option>
                                        <?php endfor; ?>
                                    </select>
                                </div>
                            </div>

                        </div>
                    </div>


                    <div class="col-md-6 padding-top-15">
                        <label class="col-md-6 col-sm-6 control-label"
                               for="married"><?php echo e(__('web/public.married')); ?> : <span class="required">*</span></label>
                        <div class="col-md-12 col-sm-10">
                            <label class="radio-inline" style="padding: 10px 40px 10px">
                                <input type="radio" name="married" checked
                                       value="<?php echo e($user->teacher->married); ?>"><?php echo e(__('web/public.married_'.$user->teacher->married)); ?>

                            </label>
                            <?php $user->teacher->married_d=$user->teacher->married=="no"?"yes":"no";?>
                            <label class="radio-inline">
                                <input type="radio" name="married"
                                       value="<?php echo e($user->teacher->married_d); ?>"><?php echo e(__('web/public.married_'.$user->teacher->married_d)); ?>

                            </label>

                            <?php $__errorArgs = ['married'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>

                <div class="row div-married div-married-yes">

                    <div class="col-md-6 padding-top-15">
                        <label class="col-md-6 col-sm-6 control-label"
                               for="number_of_children"><?php echo e(__('web/public.number_of_children')); ?> : <span
                                    class="required">*</span></label>
                        <div class="col-md-12 col-sm-10">
                            <input type="number" value="0" min="0" max="20" name="number_of_children"
                                   id="number_of_children" value="<?php echo e($user->teacher->number_of_children); ?>"
                                   class="form-control input-married input-married-yes  <?php $__errorArgs = ['number_of_children'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"/>
                            <?php $__errorArgs = ['number_of_children'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                </div>
                <div class="row div-married div-married-no">

                    <div class="col-md-6 padding-top-15">
                        <label class="col-md-6 col-sm-6 control-label"
                               for="phone_f"><?php echo e(__('web/public.phone_f')); ?> : <span class="required">*</span></label>
                        <div class="col-md-12 col-sm-10">
                            <input type="tel" placeholder="<?php echo e(__('web/public.example')); ?> : 09125555555"
                                   pattern="09[0-9]{9}" name="phone_f" id="phone_f"
                                   value="<?php echo e($user->teacher->phone_f); ?>"
                                   class="form-control   <?php $__errorArgs = ['phone_f'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"/>
                            <?php $__errorArgs = ['phone_f'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-md-6 padding-top-15">
                        <label class="col-md-6 col-sm-6 control-label"
                               for="phone_m"><?php echo e(__('web/public.phone_m')); ?> : <span class="required">*</span></label>
                        <div class="col-md-12 col-sm-10">
                            <input type="tel" placeholder="<?php echo e(__('web/public.example')); ?> : 09125555555"
                                   pattern="09[0-9]{9}" name="phone_m" id="phone_m"
                                   value="<?php echo e($user->teacher->phone_m); ?>" id="input-name"
                                   class="form-control <?php $__errorArgs = ['phone_m'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"/>
                            <?php $__errorArgs = ['phone_m'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                </div>


                <div class="row">
                    <div class="col-md-6 padding-top-15">
                        <label class="col-md-6 col-sm-6 control-label"
                               for="phone_1"><?php echo e(__('web/public.phone_1')); ?> : <span class="required">*</span></label>
                        <div class="col-md-12 col-sm-10">
                            <input type="tel" placeholder="<?php echo e(__('web/public.example')); ?> : 09125555555"
                                   pattern="09[0-9]{9}" name="phone_1" id="phone_1"
                                   value="<?php echo e($user->teacher->phone_1); ?>"
                                   class="form-control  <?php $__errorArgs = ['phone_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required disabled/>
                            <span> (<?php echo e(__('web/public.phone_1_help_2')); ?>)</span>
                            <?php $__errorArgs = ['phone_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-md-6 padding-top-15">
                        <label class="col-md-6 col-sm-6 control-label"
                               for="phone_2"><?php echo e(__('web/public.phone_2')); ?> :</label>
                        <div class="col-md-12 col-sm-10">
                            <input type="tel" placeholder="<?php echo e(__('web/public.example')); ?> : 09125555555"
                                   pattern="09[0-9]{9}" name="phone_2" id="phone_2"
                                   value="<?php echo e($user->teacher->phone_2); ?>" id="input-name"
                                   class="form-control  <?php $__errorArgs = ['phone_2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"/>
                            <?php $__errorArgs = ['phone_2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6 padding-top-15">
                        <label class="col-md-6 col-sm-6 control-label" for="tel"><?php echo e(__('web/public.tel')); ?> :
                            <span class="required">*</span></label>
                        <div class="col-md-12 col-sm-10">
                            <input type="text" name="tel" id="tel"
                                   placeholder="<?php echo e(__('web/public.example')); ?> : 02122334455"
                                   value="<?php echo e($user->teacher->tel); ?>"
                                   class="form-control  <?php $__errorArgs = ['tel'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" />
                            <?php $__errorArgs = ['tel'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-md-6 padding-top-15">
                        <label class="col-md-6 col-sm-6 control-label"
                               for="email"><?php echo e(__('web/public.email')); ?> :</label>
                        <div class="col-md-12 col-sm-10">
                            <input type="email" name="email" id="email" value="<?php echo e($user->teacher->email); ?>"
                                   class="form-control  <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"/>
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 padding-top-15">
                        <label class="col-md-6 col-sm-6 control-label"
                               for="province"><?php echo e(__('web/public.province')); ?> : <span
                                    class="required">*</span></label>
                        <div class="col-md-12 col-sm-10">
                            <select name='province' class='form-control' id="select-province" required>
                                <option value="0" selected
                                        disabled><?php echo e(__('web/public.select_option')); ?></option>
                                <?php $__currentLoopData = $provinces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>" class="option-province"
                                            id="option-province-id" <?php if($user->teacher->province==$item->id) echo "selected"; ?>><?php echo e($item->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['province'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-md-6 padding-top-15">
                        <label class="col-md-6 col-sm-6 control-label" for="city"><?php echo e(__('web/public.city')); ?>

                            : <span class="required">*</span></label>
                        <div class="col-md-12 col-sm-10">
                            <select name='city' class='form-control' id="select-city" required>
                                <option value="0" selected
                                        disabled><?php echo e(__('web/public.select_option')); ?></option>
                                <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>"
                                            class="option-city option-city-<?php echo e($item->province_id); ?>"
                                            id="option-city-<?php echo e($item->id); ?>" <?php if($user->teacher->city==$item->id) echo "selected"; ?>><?php echo e($item->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                </div>
                <div class="row">
                    <div class="col-md-6 padding-top-15">
                        <label class="col-md-6 col-sm-6 control-label"
                               for="address"><?php echo e(__('web/public.address')); ?> : <span class="required">*</span></label>
                        <div class="col-md-12 col-sm-10">
                            <input type="text" name="address" id="address" value="<?php echo e($user->teacher->address); ?>"
                                   class="form-control  <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required/>
                            <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-md-6 padding-top-15">
                        <label class="col-md-6 col-sm-6 control-label"
                               for="post_number"><?php echo e(__('web/public.post_number')); ?> : <span
                                    class="required">*</span></label>
                        <div class="col-md-12 col-sm-10">
                            <input type="text" name="post_number" id="post_number"
                                   value="<?php echo e($user->teacher->post_number); ?>" id="input-name"
                                   class="form-control  <?php $__errorArgs = ['post_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   required/>
                            <?php $__errorArgs = ['post_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 padding-top-15">
                        <label class="col-md-6 col-sm-6 control-label"
                               for="education"><?php echo e(__('web/public.education')); ?> : <span
                                    class="required">*</span></label>
                        <div class="col-md-12 col-sm-10">
                            <input type="text" name="education" id="education" value="<?php echo e($user->teacher->education); ?>"
                                   class="form-control  <?php $__errorArgs = ['education'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required/>
                            <?php $__errorArgs = ['education'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-md-6 padding-top-15">
                        <label class="col-md-6 col-sm-6 control-label" for="job"><?php echo e(__('web/public.job')); ?> :
                            <span class="required">*</span></label>
                        <div class="col-md-12 col-sm-10">
                            <input type="text" name="job" id="job" value="<?php echo e($user->teacher->job); ?>" id="input-name"
                                   class="form-control  <?php $__errorArgs = ['job'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required/>
                            <?php $__errorArgs = ['job'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
                <br><br>
                <div class="d-flex justify-content-center mb-2">
                    <div class="p-2 ">
                        <button type="submit"
                                class="btn btn-primary"><?php echo e(__('web/public.next')); ?></button>
                    </div>
                </div>

            </form>
        </div>

    </section>






<?php $__env->stopSection(); ?>



<?php echo $__env->make('teacher.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Mr Rezaei\Desktop\noor\resources\views/teacher/pages/status-2.blade.php ENDPATH**/ ?>