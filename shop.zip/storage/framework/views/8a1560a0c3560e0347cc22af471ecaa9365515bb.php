
<?php $__env->startSection('content'); ?>
    <div id="main-content">
        <div class="container-fluid">
            <div class="block-header">
                <div class="row">
                    <div class="col-lg-5 col-md-8 col-sm-12">
                        <h2><?php echo e(__('admin/public.teachers_list')); ?></h2>
                    </div>
                    <div class="col-lg-7 col-md-4 col-sm-12 text-right">
                        
                            
                        
                    </div>
                </div>
            </div>




            <div class="row clearfix">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="header">
                            <h2><?php echo e(__('admin/public.teachers_list')); ?></h2>
                        </div>
                        <div class="body">

                            <div class="table-responsive">
                                <table class="table table-bordered table-striped table-hover dataTable js-exportable">
                                    <thead>
                                    <tr>
                                        <th><?php echo e(__('admin/public.actions')); ?></th>
                                        <th><?php echo e(__('admin/public.teacher_id')); ?></th>
                                        <th><?php echo e(__('admin/public.created_at')); ?></th>
                                        <th><?php echo e(__('admin/public.level')); ?></th>
                                        <th><?php echo e(__('admin/public.sex')); ?></th>
                                        <th><?php echo e(__('admin/public.name')); ?></th>
                                        <th><?php echo e(__('admin/public.family')); ?></th>
                                        <th><?php echo e(__('admin/public.f_name')); ?></th>
                                        <th><?php echo e(__('admin/public.sh_number')); ?></th>
                                        <th><?php echo e(__('admin/public.meli_number')); ?></th>
                                        <th><?php echo e(__('admin/public.sh_sodor')); ?></th>
                                        <th><?php echo e(__('admin/public.tavalod_date')); ?></th>
                                        <th><?php echo e(__('admin/public.phone_1')); ?></th>
                                        <th><?php echo e(__('admin/public.phone_2')); ?></th>
                                        <th><?php echo e(__('admin/public.phone_f')); ?></th>
                                        <th><?php echo e(__('admin/public.phone_m')); ?></th>
                                        <th><?php echo e(__('admin/public.tel')); ?></th>
                                        <th><?php echo e(__('admin/public.province')); ?></th>
                                        <th><?php echo e(__('admin/public.city')); ?></th>
                                        <th><?php echo e(__('admin/public.address')); ?></th>
                                        <th><?php echo e(__('admin/public.post_number')); ?></th>
                                        <th><?php echo e(__('admin/public.education')); ?></th>
                                        <th><?php echo e(__('admin/public.job')); ?></th>
                                        <th><?php echo e(__('admin/public.email')); ?></th>
                                        <th><?php echo e(__('admin/public.number_of_children')); ?></th>

                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="gradeA">
                                            <td class="actions">

                                                
                                                
                                                
                                                <a href="<?php echo e(route('teachers.show',$item->id)); ?>" class="btn btn-sm btn-icon btn-pure btn-default on-default m-r-5 button-show"
                                                   data-toggle="tooltip" data-original-title="<?php echo e(__('admin/public.show')); ?>"><i class="icon-eye" aria-hidden="true"></i></a>
                                                <a href="<?php echo e(route('teachers.edit',$item->id)); ?>" class="btn btn-sm btn-icon btn-pure btn-default on-default m-r-5 button-edit"
                                                data-toggle="tooltip" data-original-title="<?php echo e(__('admin/public.edit')); ?>"><i class="icon-pencil" aria-hidden="true"></i></a>
                                                
                                                
                                                

                                            </td>
                                            <td><?php echo e($item->teacher_id); ?></td>
                                            <td><?php echo e(\App\Providers\MyProvider::show_date($item->created_at,'Y-n-j')); ?></td>
                                            <th><?php echo e(__('admin/public.teacher_status_level_'.$item->user->status)); ?></th>
                                            <td><?php echo e(__('admin/public.'.$item->sex)); ?></td>
                                            <td><?php echo e($item->name); ?></td>
                                            <td><?php echo e($item->family); ?></td>
                                            <td><?php echo e($item->f_name); ?></td>
                                            <td><?php echo e($item->sh_number); ?></td>
                                            <td><?php echo e($item->meli_number); ?></td>
                                            <td><?php echo e($item->sh_sodor); ?></td>
                                            <td><?php echo e($item->tavalod_date); ?></td>
                                            <td><?php echo e($item->phone_1); ?></td>
                                            <td><?php echo e($item->phone_2); ?></td>
                                            <td><?php echo e($item->phone_f); ?></td>
                                            <td><?php echo e($item->phone_m); ?></td>
                                            <td><?php echo e($item->tel); ?></td>
                                            <td><?php echo e($item->teachersProvince->name); ?></td>
                                            <td><?php echo e($item->teachersCity->name); ?></td>
                                            <td><?php echo e($item->address); ?></td>
                                            <td><?php echo e($item->post_number); ?></td>
                                            <td><?php echo e($item->education); ?></td>
                                            <td><?php echo e($item->job); ?></td>
                                            <td><?php echo e($item->email); ?></td>
                                            <td><?php echo e($item->number_of_children); ?></td>

                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                    </tbody>
                                    <tfoot>
                                    <tr>
                                        <th><?php echo e(__('admin/public.actions')); ?></th>
                                        <th><?php echo e(__('admin/public.teacher_id')); ?></th>
                                        <th><?php echo e(__('admin/public.created_at')); ?></th>
                                        <th><?php echo e(__('admin/public.level')); ?></th>
                                        <th><?php echo e(__('admin/public.sex')); ?></th>
                                        <th><?php echo e(__('admin/public.name')); ?></th>
                                        <th><?php echo e(__('admin/public.family')); ?></th>
                                        <th><?php echo e(__('admin/public.f_name')); ?></th>
                                        <th><?php echo e(__('admin/public.sh_number')); ?></th>
                                        <th><?php echo e(__('admin/public.meli_number')); ?></th>
                                        <th><?php echo e(__('admin/public.sh_sodor')); ?></th>
                                        <th><?php echo e(__('admin/public.tavalod_date')); ?></th>
                                        <th><?php echo e(__('admin/public.phone_1')); ?></th>
                                        <th><?php echo e(__('admin/public.phone_2')); ?></th>
                                        <th><?php echo e(__('admin/public.phone_f')); ?></th>
                                        <th><?php echo e(__('admin/public.phone_m')); ?></th>
                                        <th><?php echo e(__('admin/public.tel')); ?></th>
                                        <th><?php echo e(__('admin/public.city')); ?></th>
                                        <th><?php echo e(__('admin/public.province')); ?></th>
                                        <th><?php echo e(__('admin/public.address')); ?></th>
                                        <th><?php echo e(__('admin/public.post_number')); ?></th>
                                        <th><?php echo e(__('admin/public.education')); ?></th>
                                        <th><?php echo e(__('admin/public.job')); ?></th>
                                        <th><?php echo e(__('admin/public.email')); ?></th>
                                        <th><?php echo e(__('admin/public.number_of_children')); ?></th>

                                    </tr>
                                    </tfoot>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Mr Rezaei\Desktop\noor\resources\views/admin/teachers/index.blade.php ENDPATH**/ ?>