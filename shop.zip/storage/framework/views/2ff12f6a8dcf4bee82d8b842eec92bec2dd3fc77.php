
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li><a href="<?php echo e(route('web.show.category',$category->id)); ?>"><?php echo e(\App\Providers\MyProvider::_text($category->title)); ?>

        <?php if(isset($category->children[0]) and $category->children!=[]): ?><span>&rsaquo;</span></a>

            <div class="dropdown-menu">
                <ul>
                     <?php if (isset($component)) { $__componentOriginal296f6ba13dd9db6efa072602cb3a87131677e0bb = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\WebShowCategories::class, ['categories' => $category->children]); ?>
<?php $component->withName('web-show-categories'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                     <?php if (isset($__componentOriginal296f6ba13dd9db6efa072602cb3a87131677e0bb)): ?>
<?php $component = $__componentOriginal296f6ba13dd9db6efa072602cb3a87131677e0bb; ?>
<?php unset($__componentOriginal296f6ba13dd9db6efa072602cb3a87131677e0bb); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                </ul>
            </div>
        <?php else: ?>
        </a>
        <?php endif; ?>
    </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php /**PATH C:\Users\Mr Rezaei\Desktop\shop\resources\views/components/web-show-categories.blade.php ENDPATH**/ ?>