</div>
<?php /**PATH C:\Users\rmehdi555\Desktop\noor\resources\views/admin/section/footer.blade.php ENDPATH**/ ?>