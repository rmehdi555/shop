
<body>
<?php echo $__env->make('sweet::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="wrapper-wide">
    <div id="header">
        <!-- Top Bar Start-->
        <nav id="top" class="htop">
            <div class="container">
                <div class="row"> <span class="drop-icon visible-sm visible-xs"><i class="fa fa-align-justify"></i></span>
                    <div class="pull-left flip left-top">
                        <div class="links">
                            <ul>
                                
                                
                                
                                    
                                        
                                            
                                                
                                                    
                                                    
                                                        
                                                        
                                                    
                                                    
                                                        
                                                        
                                                    
                                                    
                                                        
                                                        
                                                    
                                                    
                                                        
                                                        
                                                    
                                                    
                                                
                                            
                                        
                                    
                                
                                
                                
                            </ul>
                        </div>
                        <div id="language" class="btn-group">
                            <button class="btn-link dropdown-toggle" data-toggle="dropdown"> <span> <?php echo e(__('web/public.lang_name_'.App::getLocale())); ?> <i class="fa fa-caret-down"></i></span></button>
                            <ul class="dropdown-menu">
                                
                                    
                                
                                <li>
                                    <a class="btn btn-link btn-block language-select" href="<?php echo e(route('web.change.lang','fa')); ?>" type="button" name="GB"><img src="<?php echo e(asset('web/2020/image/flags/fa.png')); ?>" alt="<?php echo e(__('web/public.lang_name_fa')); ?>" title="<?php echo e(__('web/public.lang_name_fa')); ?>" /> <?php echo e(__('web/public.lang_name_fa')); ?></a>
                                </li>
                                
                                    
                                
                            </ul>
                        </div>
                        <div id="currency" class="btn-group">
                            <button class="btn-link dropdown-toggle" data-toggle="dropdown"> <span> <?php echo e(__('web/public.currency_name_'.session('Local_Currency'))); ?> <i class="fa fa-caret-down"></i></span></button>
                            <ul class="dropdown-menu">
                                <li>
                                    <a class="currency-select btn btn-link btn-block" href="<?php echo e(route('web.change.currency','EUR')); ?>" type="button" name="EUR">€ Euro</a>
                                </li>
                                <li>
                                    <a class="currency-select btn btn-link btn-block" href="<?php echo e(route('web.change.currency','IRR')); ?>" type="button" name="IRR"><?php echo e(__('web/public.currency_name_IRR')); ?> IRR</a>
                                </li>
                                <li>
                                    <a class="currency-select btn btn-link btn-block" href="<?php echo e(route('web.change.currency','USD')); ?>" type="button" name="USD">$ USD</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div id="top-links" class="nav pull-right flip">
                        <?php if(auth()->check()): ?>
                            <ul>
                                <li><a href="<?php echo e(route('home')); ?>"><?php echo e(auth()->user()->name); ?> <?php echo e(auth()->user()->family); ?></a></li>
                                <li><a href="<?php echo e(route('logout')); ?>"><?php echo e(__('web/public.btn_logout')); ?></a></li>
                            </ul>

                        <?php else: ?>
                            <ul>
                                <li><a href="<?php echo e(route('login')); ?>"><?php echo e(__('web/public.btn_login')); ?></a></li>
                                <li><a href="<?php echo e(route('register')); ?>"> <?php echo e(__('web/public.btn_register')); ?></a></li>
                            </ul>
                        <?php endif; ?>


                    </div>
                </div>
            </div>
        </nav>
        <!-- Top Bar End-->
        <!-- Header Start-->
        <header class="header-row">
            <div class="container">
                <div class="table-container">
                    <!-- Logo Start -->
                    <div class="col-table-cell col-lg-6 col-md-6 col-sm-12 col-xs-12 inner">
                        <div id="logo"><a href="<?php echo e(route('web.home')); ?>"><img class="img-responsive" src="<?php echo e($siteDetailsProvider["image_logo"]->images["images"]["original"]); ?>" title="MarketShop" alt="MarketShop" /></a></div>
                    </div>
                    <!-- Logo End -->
                    <!-- Mini Cart Start-->
                    <div class="col-table-cell col-lg-3 col-md-3 col-sm-6 col-xs-12">
                        <div id="cart">
                            <button type="button" data-toggle="dropdown" data-loading-text="Loading..." class="heading dropdown-toggle">
                                <span class="cart-icon pull-left flip"></span>
                                
                            <ul class="dropdown-menu">
                                <li>
                                    <table class="table">
                                        <tbody>
                                        
                                            
                                            
                                            
                                            
                                            
                                        
                                        
                                            
                                            
                                            
                                            
                                            
                                        
                                        </tbody>
                                    </table>
                                </li>
                                <li>
                                    <div>
                                        <table class="table table-bordered">
                                            <tbody>
                                            <tr>
                                                <td class="text-right"><strong>جمع کل</strong></td>
                                                <td class="text-right">132000 تومان</td>
                                            </tr>
                                            <tr>
                                                <td class="text-right"><strong>کسر هدیه</strong></td>
                                                <td class="text-right">4000 تومان</td>
                                            </tr>
                                            <tr>
                                                <td class="text-right"><strong>مالیات</strong></td>
                                                <td class="text-right">11880 تومان</td>
                                            </tr>
                                            <tr>
                                                <td class="text-right"><strong>قابل پرداخت</strong></td>
                                                <td class="text-right">139880 تومان</td>
                                            </tr>
                                            </tbody>
                                        </table>
                                        <p class="checkout"><a href="cart.html" class="btn btn-primary"><i class="fa fa-shopping-cart"></i> مشاهده سبد</a>&nbsp;&nbsp;&nbsp;<a href="checkout.html" class="btn btn-primary"><i class="fa fa-share"></i> تسویه حساب</a></p>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <!-- Mini Cart End-->
                    <!-- جستجو Start-->
                    <div class="col-table-cell col-lg-3 col-md-3 col-sm-6 col-xs-12 inner">
                        <div id="search" class="input-group">
                            <input id="filter_name" type="text" name="search" value="" placeholder="جستجو" class="form-control input-lg" />
                            <button type="button" class="button-search"><i class="fa fa-search"></i></button>
                        </div>
                    </div>
                    <!-- جستجو End-->
                </div>
            </div>
        </header>
        <!-- Header End-->



        <!-- Main آقایانu Start-->
        <div class="container">
            <nav id="menu" class="navbar">
                <div class="navbar-header"> <span class="visible-xs visible-sm"> <?php echo e(__('web/public.menu')); ?> <b></b></span></div>
                <div class="collapse navbar-collapse navbar-ex1-collapse">
                    <ul class="nav navbar-nav">
                        <li><a class="home_link" title="<?php echo e(__('web/public.home')); ?>" href="<?php echo e(route('web.home')); ?>"><span><?php echo e(__('web/public.home')); ?></span></a></li>
                        <li class="mega-menu dropdown"><a> <?php echo e(__('web/public.categories')); ?></a>
                            <div class="dropdown-menu">
                                <?php $__currentLoopData = $categoriesProvider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($category->parent_id==0): ?>
                                        <div class="column col-lg-2 col-md-3"><a href="<?php echo e(route('web.show.category',$category->id)); ?>"><?php echo e(\App\Providers\MyProvider::_text($category->title)); ?></a>
                                            <div>
                                                <ul>
                                                    <?php if(isset($category->children[0]) and $category->children!=[]): ?>
                                                         <?php if (isset($component)) { $__componentOriginal296f6ba13dd9db6efa072602cb3a87131677e0bb = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\WebShowCategories::class, ['categories' => $category->children]); ?>
<?php $component->withName('web-show-categories'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                                                         <?php if (isset($__componentOriginal296f6ba13dd9db6efa072602cb3a87131677e0bb)): ?>
<?php $component = $__componentOriginal296f6ba13dd9db6efa072602cb3a87131677e0bb; ?>
<?php unset($__componentOriginal296f6ba13dd9db6efa072602cb3a87131677e0bb); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                                                    <?php endif; ?>
                                                </ul>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            </div>
                        </li>
                        <?php $__currentLoopData = $webMenusHeaderProvider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($menu->parent_id==0): ?>
                                <li class="dropdown information-link"><a href="<?php echo e($menu->link); ?>"><?php echo e(\App\Providers\MyProvider::_text($menu->title)); ?></a>
                                    <?php if(isset($menu->children[0]) and $menu->children!=[]): ?>
                                        <div class="dropdown-menu">
                                            <ul>
                                         <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.web-show-menus','data' => ['menus' => $menu->children]]); ?>
<?php $component->withName('web-show-menus'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['menus' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($menu->children)]); ?>
                                         <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                                            </ul>
                                        </div>
                                    <?php endif; ?>
                                </li>
                                <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </ul>
                </div>
            </nav>
        </div>
        <!-- Main آقایانu End-->
    </div>
<?php /**PATH C:\Users\Mr Rezaei\Desktop\newshop\resources\views/web/section/header.blade.php ENDPATH**/ ?>