
<?php $__env->startSection('content'); ?>
    <div class="main-inner-banner">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="main-inner-banner-cont">
                        <div class="main-inner-banner-c-title">
                            <ul class="main-breadcrumb">
                                <li><a href="<?php echo e(route('web.home')); ?>">صفحه اصلی</a></li>
                                
                            </ul>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Start: Inner main -->
    <section class="bu-inner-main">
        <div class="container">
            <div class="row">
                <div class="container p-3 my-3 bg-primary text-white align-center">
                    <h1><a href="<?php echo e(\App\Providers\MyProvider::_text($siteDetailsProvider["box_fields_link"]->value)); ?>"><?php echo \App\Providers\MyProvider::_text($siteDetailsProvider["box_fields_body"]->value); ?></a></h1>
                </div>
            </div>
        </div>
    </section>

    <!-- Start: Inner main -->
    <section class="bu-inner-main">
        <div class="container">
            <div class="row">
                <h1><?php echo e(\App\Providers\MyProvider::_text($field->title)); ?> :</h1>
                <p><?php echo \App\Providers\MyProvider::_text($field->body); ?></p>
            </div>
        </div>
    </section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rmehdi555\Desktop\noor\resources\views/web/pages/field.blade.php ENDPATH**/ ?>