
<?php $__env->startSection('content'); ?>
    <br>
    <section class="">
        <div class="container">
            <div class="row">
                <div class="col-md-1">

                </div>
                <div class="card text-white col-md-5" style="background-color: #ffb400 ; margin : 10px ; width: 100%">
                    <div class="card-header"><?php echo e(\App\Providers\MyProvider::_text($siteDetailsProvider["hadis_roz_title"]->value)); ?></div>
                    <div class="card-body">
                        <p class="card-text"><?php echo \App\Providers\MyProvider::_text($siteDetailsProvider["hadis_roz_body"]->value); ?></p>
                    </div>
                </div>
                <div class="card text-white  col-md-5" style="background-color: #002366 ; margin : 10px ; width: 100%">
                    <div class="card-header"><?php echo e(\App\Providers\MyProvider::_text($siteDetailsProvider["box_info_title"]->value)); ?></div>
                    <div class="card-body">
                        <p class="card-text"><?php echo \App\Providers\MyProvider::_text($siteDetailsProvider["box_info_body"]->value); ?></p>
                    </div>
                </div>
                <div class="col-md-1">

                </div>
            </div>
        </div>
    </section>
    <!-- Start: Iconbox -->
    <section class="main-iconbox">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="bu-title bu-margin-bottom-20">
                        <div class="bu-title-cont">
                            <h3 class="bu-title-name">امکانات </h3>
                        </div>
                    </div>
                    <div class="main-iconbox-cont">

                        <a href="<?php echo e(\App\Providers\MyProvider::_text($siteDetailsProvider["box_1_link"]->value)); ?>" class="main-iconbox-item bu-item-hover" style="background-color: #ffb400">
                            <div class="main-iconbox-i-content">
                                <h3 class="main-iconbox-ic-title"><?php echo e(\App\Providers\MyProvider::_text($siteDetailsProvider["box_1_title"]->value)); ?></h3>
                                <span class="main-iconbox-ic-more">کلیک کنید<i
                                            class="fal fa-long-arrow-left"></i></span>
                            </div>
                        </a>
                        <a href="<?php echo e(\App\Providers\MyProvider::_text($siteDetailsProvider["box_2_link"]->value)); ?>" class="main-iconbox-item bu-item-hover" style="background-color: #002366">
                            <div class="main-iconbox-i-content">
                                <h3 class="main-iconbox-ic-title"><?php echo e(\App\Providers\MyProvider::_text($siteDetailsProvider["box_2_title"]->value)); ?></h3>
                                <span class="main-iconbox-ic-more">کلیک کنید<i
                                            class="fal fa-long-arrow-left"></i></span>
                            </div>
                        </a>
                        <a href="<?php echo e(\App\Providers\MyProvider::_text($siteDetailsProvider["box_3_link"]->value)); ?>" class="main-iconbox-item bu-item-hover" style="background-color: #ffb400">
                            <div class="main-iconbox-i-content">
                                <h3 class="main-iconbox-ic-title"><?php echo e(\App\Providers\MyProvider::_text($siteDetailsProvider["box_3_title"]->value)); ?></h3>
                                <span class="main-iconbox-ic-more">کلیک کنید<i
                                            class="fal fa-long-arrow-left"></i></span>
                            </div>
                        </a>
                        <a href="<?php echo e(\App\Providers\MyProvider::_text($siteDetailsProvider["box_4_link"]->value)); ?>" class="main-iconbox-item bu-item-hover" style="background-color: #002366">
                            <div class="main-iconbox-i-content">
                                <h3 class="main-iconbox-ic-title"><?php echo e(\App\Providers\MyProvider::_text($siteDetailsProvider["box_4_title"]->value)); ?></h3>
                                <span class="main-iconbox-ic-more">کلیک کنید<i
                                            class="fal fa-long-arrow-left"></i></span>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>



    <!-- End: Iconbox -->


    <!-- Start: Banner
    <section class="main-banner">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="main-banner-slider owl-carousel owl-theme" >
                        <div class="main-banner-item"><img src="assets/img/dummy/banner-1.jpg" alt=""></div>
                        <div class="main-banner-item"><img src="assets/img/dummy/banner-2.jpg" alt=""></div>
                    </div>
                </div>
            </div>
        </div>
    </section>
     End: Banner -->

    <!-- Start: Events -->
    <section class="main-events">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="bu-title bu-margin-bottom-20">
                        <div class="bu-title-cont">
                            <h3 class="bu-title-name">آخرین اخبار</h3>
                        </div>
                    </div>
                    <div class="main-events-cont">
                        <div class="main-events-tab">
                            <ul class="nav nav-tabs " id="myTab" role="tablist">
                                <li class="nav-item">
                                    <a class="nav-link active" id="home-tab" data-toggle="tab" href="#t1" role="tab"
                                       aria-selected="true">اخبار عمومی</a>
                                </li>

                            </ul>
                            <div class="tab-content" id="myTabContent">
                                <div class="tab-pane fade show active" id="t1" role="tabpanel">
                                    <ul class="main-events-list bu-margin-bottom-30">
                                        <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <li>
                                            <h2 class="main-events-list-title bu-title-effect"><a href="<?php echo e(route('web.show.news',$item->id)); ?>">  <?php echo e(\App\Providers\MyProvider::_text($item->title)); ?> </a></h2>
                                            <span class="main-events-list-date"><?php echo e(\App\Providers\MyProvider::show_date($item->created_at,'%B %d، %Y  H:i')); ?></span>
                                        </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                    
                                        
                                            
                                            
                                        
                                    
                                </div>
                                
                                
                                
                                
                            </div>
                        </div>
                        
                            
                                
                            
                            
                                
                            
                        

                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- End: Events -->

    <!-- Start: Iconbox -->
    
        
            
                
                    
                        
                            
                        
                    
                    
                        
                            
                        
                        
                            
                        
                        
                            
                        
                        
                            
                        

                        
                            
                            
                                
                                
                            
                        
                        
                            
                            
                                
                                
                            
                        
                        
                            
                            
                                
                                
                            
                        
                        
                            
                            
                                
                                
                            
                        
                    
                
            
        
    
    <!-- End: Iconbox -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rmehdi555\Desktop\noor\resources\views/web/pages/index.blade.php ENDPATH**/ ?>