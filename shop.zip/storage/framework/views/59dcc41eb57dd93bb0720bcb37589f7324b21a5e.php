
<?php $__env->startSection('content'); ?>
    <div id="main-content">
        <div class="container-fluid">
            
            
            
            
            
            
            
            
            
            
            
            




            <div class="row clearfix">
                <div class="col-md-12">
                    <div class="card">
                        <div class="header">
                            <h2><?php echo e(__('admin/public.show')); ?></h2>
                        </div>
                        <div class="body">

                                <?php echo $__env->make('admin.section.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <?php
                                $allLang=\App\Providers\MyProvider::get_languages();
                                foreach ($allLang as $kay => $value)
                                {
                                ?>
                                <div class="form-group">
                                    <label><?php echo e(__('admin/public.title')); ?> (<?php echo e($kay); ?>):</label>
                                    <input type="text" name="title_<?php echo e($kay); ?>" class="form-control" value="<?php echo e(\App\Providers\MyProvider::_text($newsCategories->title,$kay)); ?>" required>
                                </div>
                                <?php
                                }
                                $allLang=\App\Providers\MyProvider::get_languages();
                                foreach ($allLang as $kay => $value)
                                {
                                ?>
                                <div class="form-group">
                                    <label><?php echo e(__('admin/public.description')); ?> (<?php echo e($kay); ?>):</label>
                                    <textarea name="description_<?php echo e($kay); ?>" id="ckeditor" class="form-control" rows="5" cols="30" required><?php echo e(\App\Providers\MyProvider::_text($newsCategories->description,$kay)); ?></textarea>

                                </div>
                                <?php
                                }
                                $allLang=\App\Providers\MyProvider::get_languages();
                                foreach ($allLang as $kay => $value)
                                {
                                ?>
                                <div class="form-group">
                                    <label><?php echo e(__('admin/public.body')); ?> (<?php echo e($kay); ?>):</label>
                                    <textarea name="body_<?php echo e($kay); ?>" class="form-control ckeditor" rows="5" cols="30" required><?php echo e(\App\Providers\MyProvider::_text($newsCategories->body,$kay)); ?></textarea>

                                </div>
                                <?php
                                }
                                ?>
                                <div class="form-group">
                                    <label><?php echo e(__('admin/public.images')); ?> :</label>
                                    <input type="file" name="images" class="form-control" value="<?php echo e(old('images')); ?>" >
                                </div>
                                <?php if($newsCategories->images!=[]): ?>
                                    <div class="media">
                                        <img class="media-object " src="<?php echo e($newsCategories->images["thumb"]); ?>" alt="">
                                        
                                        
                                        
                                        
                                        
                                    </div>
                                <?php endif; ?>
                                <div class="form-group">
                                    <label><?php echo e(__('admin/public.tags')); ?> :</label>
                                    <input type="text" name="tags" class="form-control" value="<?php echo e($newsCategories->tags); ?>" required>
                                </div>
                                <div class="form-group">
                                    <label><?php echo e(__('admin/public.priority')); ?> :</label>
                                    <input type="number" name="priority" class="form-control" value="<?php echo e($newsCategories->priority); ?>" required>
                                </div>
                                <div class="form-group">
                                    <label><?php echo e(__('admin/public.icon')); ?> :</label>
                                    <input type="text" name="icon" class="form-control" value="<?php echo e($newsCategories->icon); ?>" required>
                                </div>


                                <div class="form-group col-lg-4 col-md-12">
                                    <label><?php echo e(__('admin/public.parent_id')); ?> :</label>
                                    <div class="multiselect_div">
                                        <select id="single-selection" name="parent_id" class="multiselect multiselect-custom" >
                                            <option value="0"><?php echo e(__('admin/public.base_parent_id')); ?></option>
                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($category->id); ?>"><?php echo e(\App\Providers\MyProvider::_text($category->title)); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="form-group col-lg-4 col-md-12">
                                    <label><?php echo e(__('admin/public.status')); ?> :</label>
                                    <div class="multiselect_div">
                                        <select id="single-selection" name="status" class="multiselect multiselect-custom" >
                                            <option value="0"><?php echo e(__('admin/public.inactive')); ?></option>
                                            <option value="1" <?php echo e($newsCategories->status?"selected":""); ?>><?php echo e(__('admin/public.active')); ?></option>
                                        </select>
                                    </div>
                                </div>





                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Mr Rezaei\Desktop\shop\resources\views/admin/news-categories/show.blade.php ENDPATH**/ ?>