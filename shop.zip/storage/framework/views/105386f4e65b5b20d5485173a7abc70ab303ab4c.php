
<?php $__env->startSection('content'); ?>

    <section class="bu-inner-main">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="alert alert-info m-1">
                        <p class="p-1 text-justify">معلم گرامی
                            <?php echo e($user->teacher->name); ?>  <?php echo e($user->teacher->family); ?>

                 مدارک مورد نیاز در ذیل را بارگذاری نمایید .
                        </p>
                        <p>
                            یادسپاری: بارگذاری سوابق و مدارک قرآنی و نیز مدرک تحصیلی، در مصاحبه و فرایند گزینش حائذ اهمیت می باشد.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="bu-inner-main">
        <div class="container">
            <form class="form-horizontal" id="form-level-1-save" method="POST"
                  action="<?php echo e(route('teacher.level.1.save')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php if(count($errors) > 0): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
            <div class="row">
                <div class="col-md-6 padding-top-15">
                    <label class="col-md-6 col-sm-6 control-label"
                           for="meli_image"><?php echo e(__('web/public.meli_image')); ?> : <span
                                class="required">*</span> </label>
                    <div class="col-md-12 col-sm-10">
                        <div class="custom-file ">
                            <input type="file" class="custom-file-input " id="customFile" name="meli_image" required>
                            <label class="custom-file-label text-align-left" for="customFile"></label>
                        </div>
                        <?php $__errorArgs = ['meli_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
            </div>
                <div class="row">
                    <div class="col-md-6 padding-top-15">
                        <label class="col-md-6 col-sm-6 control-label"
                               for="sh_1_image"><?php echo e(__('web/public.sh_1_image')); ?> : <span
                                    class="required">*</span> </label>
                        <div class="col-md-12 col-sm-10">
                            <div class="custom-file ">
                                <input type="file" class="custom-file-input " id="customFile" name="sh_1_image" required>
                                <label class="custom-file-label text-align-left" for="customFile"></label>
                            </div>
                            <?php $__errorArgs = ['sh_1_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-md-6 padding-top-15">
                        <label class="col-md-6 col-sm-6 control-label"
                               for="sh_2_image"><?php echo e(__('web/public.sh_2_image')); ?> : <span
                                    class="required">*</span></label>
                        <div class="col-md-12 col-sm-10">
                            <div class="custom-file ">
                                <input type="file" class="custom-file-input" id="customFile" name="sh_2_image" required>
                                <label class="custom-file-label" for="customFile"></label>
                            </div>
                            <?php $__errorArgs = ['sh_2_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6 padding-top-15">
                        <label class="col-md-9 col-sm-9 control-label"
                               for="p_image"><?php echo e(__('web/public.p_image')); ?>  : </label>
                        <div class="col-md-12 col-sm-10">
                            <div class="custom-file ">
                                <input type="file" class="custom-file-input " id="customFile" name="p_image" >
                                <label class="custom-file-label text-align-left" for="customFile"></label>
                            </div>
                            <?php $__errorArgs = ['p_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-md-6 padding-top-15">
                        <label class="col-md-6 col-sm-6 control-label"
                               for="m_image"><?php echo e(__('web/public.m_image')); ?> : </label>
                        <div class="col-md-12 col-sm-10">
                            <div class="custom-file ">
                                <input type="file" class="custom-file-input" id="customFile" name="m_image" >
                                <label class="custom-file-label" for="customFile"></label>
                            </div>
                            <?php $__errorArgs = ['m_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>

                <br><br>

                <div class="row">
                    <div class="col-md-12">
                        <div class="d-flex justify-content-center mb-2 ">
                            <div class="p-2 contract-div-hide">
                                <button type="submit"
                                        class="btn btn-primary"><?php echo e(__('web/public.btn_upload')); ?></button>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>

    </section>






<?php $__env->stopSection(); ?>



<?php echo $__env->make('teacher.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Mr Rezaei\Desktop\noor\resources\views/teacher/pages/status-1.blade.php ENDPATH**/ ?>