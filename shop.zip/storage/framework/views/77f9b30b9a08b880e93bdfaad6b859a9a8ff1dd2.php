
<?php $__env->startSection('content'); ?>
    <div class="main-inner-banner">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="main-inner-banner-cont">
                        <div class="main-inner-banner-c-title">
                            <ul class="main-breadcrumb">
                                <li><a href="<?php echo e(route('web.home')); ?>"><?php echo e(__('web/public.home_page')); ?></a></li>
                                
                            </ul>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <section class="bu-inner-main">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="alert alert-info m-1">
                        <a href="<?php echo e(\App\Providers\MyProvider::_text($siteDetailsProvider["box_students_level_link"]->value)); ?>">
                            <p class="p-1 text-justify"><?php echo \App\Providers\MyProvider::_text($siteDetailsProvider["box_students_level_body"]->value); ?></p>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Start: Inner main -->
    <section class="bu-inner-main">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="alert alert-primary m-1">
                        <?php echo \App\Providers\MyProvider::_text($siteDetailsProvider["page_students_level_1_body"]->value); ?>

                    </div>
                </div>
            </div>

        </div>
    </section>



    <!-- Start: Inner main -->
    <section class="bu-inner-main">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="bu-inner-main-form">
                        <?php if(count($errors) > 0): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>

                        <form class="form-horizontal" id="form-level-1-save" method="POST"
                              action="<?php echo e(route('web.students.level.1.save')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-md-6">
                                    <label for="input-name"><?php echo e(__('web/public.select_class_type')); ?> :</label>
                                </div>
                                <div class="col-md-6">
                                    <div class="col-md-10 col-sm-9">
                                        <label class="radio-inline">
                                            <input type="radio" name="class_type"
                                                   value="<?php echo e(__('web/public.select_class_type_online')); ?>"
                                                   checked><?php echo e(__('web/public.select_class_type_online')); ?>

                                        </label>
                                        <label class="radio-inline">
                                            <input type="radio"
                                                   name="class_type"
                                                   value="<?php echo e(__('web/public.select_class_type_verbal')); ?>"><?php echo e(__('web/public.select_class_type_verbal')); ?>

                                        </label>
                                        <?php $__errorArgs = ['class_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                            </div>
                        </form>
                        <br><br>


                        <form class="form-horizontal" method="POST" action="<?php echo e(route('web.students.field.add')); ?>">
                            <?php echo csrf_field(); ?>
                            <p class="bu-margin-bottom-30"><?php echo e(__('web/public.student_field_add_new')); ?> : </p>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group ">
                                        <label class=" control-label"
                                               for="input-name"><?php echo e(__('web/public.select_field_main')); ?> : <span class="required">*</span> </label>
                                        <div class="col-md-10 col-sm-9">
                                            <select name="field_main" id="select-field-main"
                                                    class="form-control  <?php $__errorArgs = ['field_main'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                <?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($item->parent_id==0): ?>
                                                        <option class="option-field-main"
                                                                id="option-field-main-<?php echo e($item->id); ?>"
                                                                value="<?php echo e($item->id); ?>" <?php if($item->status==0)echo"disabled";?>><?php echo e(\App\Providers\MyProvider::_text($item->title)); ?></option>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <?php $__errorArgs = ['field_main'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group ">
                                        <label class=" control-label"
                                               for="input-name"><?php echo e(__('web/public.select_field_child')); ?> : <span class="required">*</span></label>
                                        <div class="col-md-10 col-sm-9">
                                            <select name="field_child" id="select-field-child"
                                                    class="form-control  <?php $__errorArgs = ['field_main'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required >
                                                
                                                <?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($item->parent_id!=0 OR !isset($item->children[1])): ?>
                                                        <option class="option-field-child option-field-child-<?php echo e($item->parent_id==0?$item->id:$item->parent_id); ?>"
                                                                id="option-field-child-<?php echo e($item->id); ?>"
                                                                value="<?php echo e($item->id); ?>" <?php if($item->status==0)echo"disabled";?>><?php echo e(\App\Providers\MyProvider::_text($item->title)); ?></option>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <?php $__errorArgs = ['field_child'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                                <?php if(count($studentFields)>0): ?>
                                    <div class="col-md-4">
                                        <label class=" control-label"
                                               for="input-name"><br></label>
                                        <div class="buttons">
                                            <div class="pull-right">
                                                <input type="submit" class="btn btn-primary"
                                                       value="<?php echo e(__('web/public.btn_add_field')); ?>">
                                            </div>
                                        </div>
                                    </div>
                                <?php else: ?>
                                    <div class="col-md-4">
                                        <label class=" control-label"
                                               for="input-name"><br></label>
                                        <div class="buttons">
                                            <div class="pull-right">
                                                <input type="submit" class="btn btn-primary"
                                                       value="<?php echo e(__('web/public.select')); ?>">
                                            </div>
                                        </div>
                                    </div>
                                    <?php endif; ?>


                            </div>

                            <fieldset>


                            </fieldset>

                        </form>


                        <br><br>
                        <?php if(count($studentFields)>0): ?>
                            <p class="bu-margin-bottom-30"><?php echo e(__('web/public.student_field_select')); ?> : </p>
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                    <tr>
                                        <th>#</th>
                                        <th><?php echo e(__('web/public.title_field')); ?></th>
                                        <th><?php echo e(__('web/public.price')); ?>(<?php echo e(__('web/public.currency_name_IRR')); ?>)</th>
                                        <th><?php echo e(__('web/public.setting')); ?></th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $i=1; $finalPrice=0;?>
                                    <?php $__currentLoopData = $studentFields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($i); ?></td>
                                            <td><?php echo e($item->title); ?></td>
                                            <td><?php echo e(number_format($item->price)); ?></td>
                                            <td><a class="btn btn-danger btn-sm"
                                                   href="<?php echo e(route('web.students.field.delete',$item->id)); ?>"><?php echo e(__('web/public.delete')); ?></a>
                                            </td>
                                        </tr>
                                        <?php $i++; $finalPrice+=$item->price; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="table-primary">
                                        <td colspan='2'><?php echo e(__('web/public.price_final')); ?>

                                            (<?php echo e(__('web/public.currency_name_IRR')); ?>) :
                                        </td>
                                        <td colspan='2'><?php echo e($finalPrice); ?></td>
                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                            <br><br>
                            <div class="d-flex justify-content-center mb-2">
                                <div class="p-2"><a class="btn btn-danger"
                                                    href="<?php echo e(route('web.students.level.1.cancel')); ?>"><?php echo e(__('web/public.cancel')); ?></a>
                                </div>
                                <div class="p-2 ">
                                    <button id="button-level-1-save"
                                            class="btn btn-primary"><?php echo e(__('web/public.next')); ?></button>
                                </div>
                            </div>

                        <?php endif; ?>


                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Start: Inner main -->





<?php $__env->stopSection(); ?>



<?php echo $__env->make('web.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Mr Rezaei\Desktop\noor\resources\views/web/pages/students-level-1.blade.php ENDPATH**/ ?>