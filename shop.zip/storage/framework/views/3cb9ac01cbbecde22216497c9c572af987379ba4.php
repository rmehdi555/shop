
<?php $__env->startSection('content'); ?>
    <div class="main-inner-banner">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="main-inner-banner-cont">
                        <div class="main-inner-banner-c-title">
                            <ul class="main-breadcrumb">
                                <li><a href="<?php echo e(route('web.home')); ?>"><?php echo e(__('web/public.home_page')); ?></a></li>
                                
                            </ul>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <section class="bu-inner-main">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="alert alert-info m-1">

                            <p class="p-1 text-justify"><?php echo \App\Providers\MyProvider::_text($siteDetailsProvider["box_teachers_level_body"]->value); ?></p>

                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Start: Inner main -->



    <!-- Start: Inner main -->
    <section class="bu-inner-main">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="bu-inner-main-form">
                        <?php if(count($errors) > 0): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>

                        <?php if($siteDetailsProvider["status_register_m"]->status==1): ?>
                                <br><br>
                                <div class="d-flex justify-content-center mb-2">
                                    <div class="p-2"><a class="btn btn-danger"
                                                        href="<?php echo e(route('web.teachers.level.1.cancel')); ?>"><?php echo e(__('web/public.cancel')); ?></a>
                                    </div>
                                    <div class="p-2 ">
                                        <a id="button-level-1-save"
                                           class="btn btn-primary"  href="<?php echo e(route('web.teachers.level.2')); ?>"><?php echo e(__('web/public.next')); ?></a>
                                    </div>
                                </div>
                            <?php else: ?>
                                <section class="bu-inner-main">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="alert alert-warning m-1">

                                                    <p class="p-1 text-justify">
                                                        <?php echo \App\Providers\MyProvider::_text($siteDetailsProvider["status_register_m"]->value); ?>

                                                    </p>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </section>
                            <?php endif; ?>




                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Start: Inner main -->





<?php $__env->stopSection(); ?>



<?php echo $__env->make('web.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Mr Rezaei\Desktop\noor\resources\views/web/pages/teachers-level-1.blade.php ENDPATH**/ ?>