</div>
<?php /**PATH C:\Users\Mr Rezaei\Desktop\newshop\resources\views/admin/section/footer.blade.php ENDPATH**/ ?>