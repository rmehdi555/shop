</div>
<?php /**PATH C:\Users\Mr Rezaei\Desktop\noor\resources\views/admin/section/footer.blade.php ENDPATH**/ ?>