
<?php $__env->startSection('content'); ?>

    <div id="container">
        <div class="container">
            <div class="row">
                <!--Middle Part Start-->
                <div id="content" class="col-sm-12">
                    <h1 class="title-404 text-center">404</h1>
                    <p class="text-center lead"><?php echo e(__('web/messages.404_1')); ?><br>
                        <?php echo e(__('web/messages.404_2')); ?> </p>
                    <div class="buttons text-center"> <a class="btn btn-primary btn-lg" href="<?php echo e(route('web.index')); ?>"> <?php echo e(__('web/public.continuation')); ?></a> </div>
                </div>
                <!--Middle Part End -->
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Mr Rezaei\Desktop\shop\resources\views/web/pages/404.blade.php ENDPATH**/ ?>