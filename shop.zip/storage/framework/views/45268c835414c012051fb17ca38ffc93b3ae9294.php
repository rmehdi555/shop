
<?php $__env->startSection('content'); ?>

    <section class="bu-inner-main">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="alert alert-info m-1">
                        <p class="p-1 text-justify">کاربر گرامی
                            <?php echo e($user->student->name); ?>  <?php echo e($user->student->family); ?>

                  درخواست شما جهت بررسی عضو نهاد خاص بودن به درستی ارسال گردید ، بعد از بررسی توسط کارشناسان ما جواب را در همین پنل کاربری ارائه میدهد .
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>







<?php $__env->stopSection(); ?>



<?php echo $__env->make('student.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Mr Rezaei\Desktop\noor\resources\views/student/pages/status-2.blade.php ENDPATH**/ ?>