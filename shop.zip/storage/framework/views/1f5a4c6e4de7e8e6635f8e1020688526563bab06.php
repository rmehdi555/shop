
<?php $__env->startSection('content'); ?>
    <div id="main-content">
        <div class="container-fluid">
            <div class="block-header">
                <div class="row">
                    <div class="col-lg-5 col-md-8 col-sm-12">
                        <h2><?php echo e(__('admin/public.noors_list')); ?></h2>
                    </div>
                    <div class="col-lg-7 col-md-4 col-sm-12 text-right">
                        
                            
                        
                    </div>
                </div>
            </div>




            <div class="row clearfix">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="header">
                            <h2><?php echo e(__('admin/public.noors_list')); ?></h2>
                        </div>
                        <div class="body">

                            <div class="table-responsive">
                                <table class="table table-bordered table-striped table-hover dataTable js-exportable">
                                    <thead>
                                    <tr>
                                        <th><?php echo e(__('admin/public.noor_id')); ?></th>
                                        <th><?php echo e(__('admin/public.created_at')); ?></th>
                                        <th><?php echo e(__('admin/public.level')); ?></th>
                                        <th><?php echo e(__('admin/public.noor_type')); ?></th>
                                        <th><?php echo e(__('admin/public.mobile')); ?></th>
                                        <th><?php echo e(__('admin/public.noor_description')); ?></th>
                                        <th><?php echo e(__('admin/public.price')); ?>(<?php echo e(__('web/public.currency_name_IRR')); ?>)</th>
                                        <th><?php echo e(__('admin/public.sex')); ?></th>
                                        <th><?php echo e(__('admin/public.name')); ?></th>
                                        <th><?php echo e(__('admin/public.family')); ?></th>
                                        <th><?php echo e(__('admin/public.f_name')); ?></th>
                                        <th><?php echo e(__('admin/public.meli_number')); ?></th>
                                        <th><?php echo e(__('admin/public.monthly_payment')); ?></th>

                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $noors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $item->monthly_payment=$item->monthly_payment==0?'no':'yes';
                                        ?>

                                        <?php if($item->type!='کمک های نقدی')$item->monthly_payment='no';?>

                                        <tr class="gradeA">
                                            <td><?php echo e($item->id); ?></td>
                                            <td><?php echo e(\App\Providers\MyProvider::show_date($item->created_at,'Y-n-j')); ?></td>
                                            <th><?php echo e(__('admin/public.noor_status_level_'.$item->status)); ?></th>
                                            <td><?php echo e($item->type); ?></td>
                                            <td><?php echo e($item->mobile); ?></td>
                                            <td><?php echo e($item->description); ?></td>
                                            <td><?php echo e(number_format($item->price)); ?></td>
                                            <td><?php echo e(__('admin/public.'.$item->sex)); ?></td>
                                            <td><?php echo e($item->name); ?></td>
                                            <td><?php echo e($item->family); ?></td>
                                            <td><?php echo e($item->f_name); ?></td>
                                            <td><?php echo e($item->meli_number); ?></td>
                                            <td><?php echo e(__('admin/public.'.$item->monthly_payment)); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                    </tbody>
                                    <tfoot>
                                    <tr>
                                        <th><?php echo e(__('admin/public.noor_id')); ?></th>
                                        <th><?php echo e(__('admin/public.created_at')); ?></th>
                                        <th><?php echo e(__('admin/public.level')); ?></th>
                                        <th><?php echo e(__('admin/public.noor_type')); ?></th>
                                        <th><?php echo e(__('admin/public.mobile')); ?></th>
                                        <th><?php echo e(__('admin/public.noor_description')); ?></th>
                                        <th><?php echo e(__('admin/public.price')); ?>(<?php echo e(__('web/public.currency_name_IRR')); ?>)</th>
                                        <th><?php echo e(__('admin/public.sex')); ?></th>
                                        <th><?php echo e(__('admin/public.name')); ?></th>
                                        <th><?php echo e(__('admin/public.family')); ?></th>
                                        <th><?php echo e(__('admin/public.f_name')); ?></th>
                                        <th><?php echo e(__('admin/public.meli_number')); ?></th>
                                        <th><?php echo e(__('admin/public.monthly_payment')); ?></th>

                                    </tr>
                                    </tfoot>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Mr Rezaei\Desktop\noor\resources\views/admin/noors/index.blade.php ENDPATH**/ ?>