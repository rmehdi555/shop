<!-- Feature Box End-->
<div id="container">
    <!-- Feature Box Start-->
    <div class="container">
        <div class="custom-feature-box row">

        </div>
    </div>
    <!-- Feature Box End-->
<div class="container">
    <div class="row">
        <!-- Left Part Start-->
        <aside id="column-left" class="col-sm-3 hidden-xs">
            <h3 class="subtitle"> <?php echo e(__('user/public.panel')); ?></h3>
            <div class="box-category">
                <ul id="cat_accordion">
                    <li>
                        <a href="<?php echo e(route('user.panel')); ?>"><?php echo e(__('user/public.panel')); ?> <?php echo e(auth()->user()->name); ?> <?php echo e(auth()->user()->family); ?> </a>
                        <a href="<?php echo e(route('logout')); ?>"><?php echo e(__('user/public.btn_logout')); ?></a>
                    </li>
                </ul>


        </aside>
<?php /**PATH C:\Users\Mr Rezaei\Desktop\shop\resources\views/user/section/user-side.blade.php ENDPATH**/ ?>