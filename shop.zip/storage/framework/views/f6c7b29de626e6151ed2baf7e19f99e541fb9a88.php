
<?php $__env->startSection('content'); ?>
    <div class="main-inner-banner">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="main-inner-banner-cont">
                        <div class="main-inner-banner-c-title">
                            <ul class="main-breadcrumb">
                                <li><a href="<?php echo e(route('web.home')); ?>"><?php echo e(__('web/public.home_page')); ?></a></li>
                                
                            </ul>
                            <h1 class="main-inner-banner-ct-name"><?php echo e(__('web/public.contact_us')); ?></h1>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Start: Inner main -->
    <section class="bu-inner-main">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="bu-inner-main-cont">
                        <p class="bu-margin-bottom-30"><?php echo e(__('web/public.contact_us')); ?></p>
                        <div class="bu-inner-main-contact">
                            <div class="bu-inner-mc-form  bu-margin-bottom-30">
                                <form class="form-horizontal" method="POST" action="<?php echo e(route('web.contact.us.insert')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <fieldset>

                                        <?php if(count($errors) > 0): ?>
                                            <div class="alert alert-danger">
                                                <ul>
                                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <li><?php echo e($error); ?></li>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </ul>
                                            </div>
                                        <?php endif; ?>
                                        <div class="form-group required">
                                            <label class="col-md-2 col-sm-3 control-label" for="input-name"><?php echo e(__('web/public.name')); ?></label>
                                            <div class="col-md-10 col-sm-9">
                                                <input type="text" name="name" value="<?php echo e(old('name')); ?>" id="input-name" class="form-control  <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" />
                                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <div class="form-group required">
                                            <label class="col-md-2 col-sm-3 control-label" for="input-name"><?php echo e(__('web/public.family')); ?></label>
                                            <div class="col-md-10 col-sm-9">
                                                <input type="text" name="family" value="<?php echo e(old('family')); ?>" id="input-name" class="form-control  <?php $__errorArgs = ['family'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" />
                                                <?php $__errorArgs = ['family'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <div class="form-group required">
                                            <label class="col-md-2 col-sm-3 control-label" for="input-email">آدرس ایمیل</label>
                                            <div class="col-md-10 col-sm-9">
                                                <input type="email" name="email" value="<?php echo e(old('email')); ?>" id="input-email" class="form-control  <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" />
                                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <div class="form-group required">
                                            <label class="col-md-2 col-sm-3 control-label" for="input-name"><?php echo e(__('web/public.phone')); ?></label>
                                            <div class="col-md-10 col-sm-9">
                                                <input type="text" name="phone" value="<?php echo e(old('phone')); ?>" id="input-name" class="form-control  <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" />
                                                <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <div class="form-group required">
                                            <label class="col-md-2 col-sm-3 control-label" for="input-enquiry"><?php echo e(__('web/public.body_contact_us')); ?></label>
                                            <div class="col-md-10 col-sm-9">
                                                <textarea name="body" rows="10" id="input-enquiry" class="form-control  <?php $__errorArgs = ['body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"><?php echo e(old('body')); ?></textarea>
                                                <?php $__errorArgs = ['body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                    </fieldset>
                                    <div class="buttons">
                                        <div class="pull-right">
                                            <input type="submit" class="btn btn-primary" value="<?php echo e(__('web/public.submit')); ?>">
                                        </div>
                                    </div>
                                </form>
                            </div>
                            <div class="bu-inner-mc-info">
                                <div class="bu-title-cont bu-margin-bottom-20">
                                    <span class="bu-title-icon sqaure"></span>
                                    <h3 class="bu-title-name"> ارتباط با ما</h3>
                                </div>
                                <ul class="main-footer-contact-list main-inner-mc-info-list">
                                    <li>
                                        <i class="fal fa-location-arrow"></i>
                                        <?php echo \App\Providers\MyProvider::_text($siteDetailsProvider["address"]->value); ?>

                                    </li>
                                    <li>
                                        <i class="fal fa-envelope"></i>
                                        <?php echo e(\App\Providers\MyProvider::_text($siteDetailsProvider["email"]->value)); ?>

                                    </li>
                                    <li>
                                        <i class="fal fa-phone"></i>
                                        <?php echo \App\Providers\MyProvider::_text($siteDetailsProvider["phone"]->value); ?>

                                    </li>
                                    <li>
                                        <i class="fal fa-phone"></i>
                                        <?php echo \App\Providers\MyProvider::_text($siteDetailsProvider["mobile"]->value); ?>

                                    </li>
                                </ul>
                                <ul class="main-header-trs-list main-inner-mc-social-list">
                                    <li><a href="<?php echo e(\App\Providers\MyProvider::_text($siteDetailsProvider["instagram"]->value)); ?>" target="_blank"><i class="fab fa-instagram"></i></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Start: Inner main -->



<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Mr Rezaei\Desktop\noor\resources\views/web/pages/contact-us.blade.php ENDPATH**/ ?>