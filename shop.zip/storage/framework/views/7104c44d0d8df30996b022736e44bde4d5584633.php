
<?php $__env->startSection('content'); ?>
    <div id="main-content">
        <div class="container-fluid">
            <div class="block-header">
                <div class="row">
                    <div class="col-lg-5 col-md-8 col-sm-12">
                        <h2>پنل مدیریت</h2>
                    </div>
                    <div class="col-lg-7 col-md-4 col-sm-12 text-right">
                        <ul class="breadcrumb justify-content-end">
                            
                            
                            
                        </ul>
                    </div>
                </div>
            </div>

            <div class="row clearfix">
                <div class="col-lg-4 col-md-12">
                    <div class="card weather2">
                        <div class="body city-selected">
                            <div class="row">
                                <div class="col-12">

                                </div>
                                <div class="info col-12">
                                    <div class="temp"><h2><?php echo e(auth()->user()->name); ?> <?php echo e(auth()->user()->family); ?></h2></div>
                                </div>
                                <div class="icon col-5">

                                </div>
                            </div>
                        </div>
                        <table class="table table-striped m-b-0">
                            <tbody>
                            <tr>
                                <td>تاریخ امروز :</td>
                                <td class="font-medium"><?php use Hekmatinasser\Verta\Verta;$v=Verta::now();    echo($v->formatWord('l').' '.$v->format('d').' '.$v->formatWord('F').' '.$v->format('Y'));?></td>
                            </tr>

                            </tbody>
                        </table>

                    </div>
                </div>
                <div class="col-lg-8 col-md-12">
                    <div class="card">
                        <div class="header">
                            <h2>آمار بازدید های سایت </h2>
                            <ul class="header-dropdown">
                                
                                
                                
                                    
                                    
                                        
                                        
                                        
                                    
                                
                            </ul>
                        </div>
                        <div class="body">
                            <div class="row text-center">
                                <div class="col-lg-3 col-md-6 col-6">
                                    <div class="body xl-parpl">
                                        <h4><?php echo e($visitArray["getAllUser"]); ?></h4>
                                        <span>تعداد همه افراد بازدید کننده تا به امروز</span>
                                    </div>
                                </div>
                                <div class="col-lg-3 col-md-6 col-6">
                                    <div class="body xl-turquoise">
                                        <h4><?php echo e($visitArray["getAllPage"]); ?></h4>
                                        <span>تعداد همه برگه های بازدید شده تا به امروز</span>
                                    </div>
                                </div>
                                <div class="col-lg-3 col-md-6 col-6">
                                    <div class="body xl-salmon">
                                        <h4><?php echo e($visitArray["getAllUserToday"]); ?></h4>
                                        <span>تعداد افراد بازدید کننده امروز</span>
                                    </div>
                                </div>
                                <div class="col-lg-3 col-md-6 col-6">
                                    <div class="body xl-slategray">
                                        <h4><?php echo e($visitArray["getAllPageToday"]); ?></h4>
                                        <span>تعداد صفحه های بازدید شده امروز</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Mr Rezaei\Desktop\shop\resources\views/admin/panel.blade.php ENDPATH**/ ?>