
<?php $__env->startSection('content'); ?>
    <div id="main-content">
        <div class="container-fluid">
            
            
            
            
            
            
            
            
            
            
            
            




            <div class="row clearfix">
                <div class="col-md-12">
                    <div class="card">
                        <div class="header">
                            <h2><?php echo e(__('admin/public.edit')); ?></h2>
                        </div>
                        <div class="body">
                            <form id="basic-form" action="<?php echo e(route('fields.update',$field->id)); ?>" method="post" enctype="multipart/form-data" novalidate>
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PATCH'); ?>
                                <?php echo $__env->make('admin.section.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <?php
                                $allLang=\App\Providers\MyProvider::get_languages();
                                foreach ($allLang as $kay => $value)
                                {
                                ?>
                                <div class="form-group">
                                    <label><?php echo e(__('admin/public.title')); ?> (<?php echo e($kay); ?>):</label>
                                    <input type="text" name="title_<?php echo e($kay); ?>" class="form-control" value="<?php echo e(\App\Providers\MyProvider::_text($field->title,$kay)); ?>" required>
                                </div>
                                <?php
                                }
                                $allLang=\App\Providers\MyProvider::get_languages();
                                foreach ($allLang as $kay => $value)
                                {
                                ?>
                                <div class="form-group">
                                    <label><?php echo e(__('admin/public.description')); ?> (<?php echo e($kay); ?>):</label>
                                    <textarea name="description_<?php echo e($kay); ?>" id="description_<?php echo e($kay); ?>" class="form-control" rows="5" cols="30" required><?php echo e(\App\Providers\MyProvider::_text($field->description,$kay)); ?></textarea>

                                </div>
                                <?php
                                }
                                $allLang=\App\Providers\MyProvider::get_languages();
                                foreach ($allLang as $kay => $value)
                                {
                                    ?>
                                <div class="form-group">
                                    <label><?php echo e(__('admin/public.body')); ?> (<?php echo e($kay); ?>):</label>
                                    <textarea name="body_<?php echo e($kay); ?>" class="form-control ckeditor" rows="5" cols="30" required><?php echo e(\App\Providers\MyProvider::_text($field->body,$kay)); ?></textarea>

                                </div>
                                <?php
                                }
                                ?>
                                <div class="form-group">
                                    <label><?php echo e(__('admin/public.images')); ?> :</label>
                                    <input type="file" name="images" class="form-control" value="<?php echo e(old('images')); ?>" >
                                </div>
                                <?php if($field->images!=[]): ?>
                                <div class="media">
                                    <img class="media-object " src="<?php echo e($field->images["thumb"]); ?>" alt="">
                                    
                                    
                                    
                                    
                                    
                                </div>
                                <?php endif; ?>
                                <div class="form-group">
                                    <label><?php echo e(__('admin/public.tags')); ?> :</label>
                                    <input type="text" name="tags" class="form-control" value="<?php echo e($field->tags); ?>" required>
                                </div>
                                <div class="form-group">
                                    <label><?php echo e(__('admin/public.priority')); ?> :</label>
                                    <input type="number" name="priority" class="form-control" value="<?php echo e($field->priority); ?>" required>
                                </div>
                                <div class="form-group">
                                    <label><?php echo e(__('admin/public.price')); ?> (<?php echo e(__('admin/public.IRR')); ?>) :</label>
                                    <input type="number" name="price" class="form-control" value="<?php echo e($field->price); ?>"
                                           required>
                                </div>


                                <div class="form-group col-lg-4 col-md-12">
                                    <label><?php echo e(__('admin/public.parent_id')); ?> :</label>
                                    <div class="multiselect_div">
                                        <select id="single-selection" name="parent_id" class="multiselect multiselect-custom" >
                                            <option value="0"><?php echo e(__('admin/public.base_parent_id')); ?></option>
                                            <?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($item->id); ?>" <?php echo e($item->id==$field->parent_id?"selected":""); ?>><?php echo e(\App\Providers\MyProvider::_text($item->title)); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="form-group col-lg-4 col-md-12">
                                    <label><?php echo e(__('admin/public.status')); ?> :</label>
                                    <div class="multiselect_div">
                                        <select id="single-selection" name="status" class="multiselect multiselect-custom" >
                                            <option value="0"><?php echo e(__('admin/public.inactive')); ?></option>
                                            <option value="1" <?php echo e($field->status?"selected":""); ?>><?php echo e(__('admin/public.active')); ?></option>
                                        </select>
                                    </div>
                                </div>






                                <br>
                                <button type="submit" class="btn btn-primary"><?php echo e(__('admin/public.submit')); ?></button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Mr Rezaei\Desktop\noor\resources\views/admin/fields/edit.blade.php ENDPATH**/ ?>