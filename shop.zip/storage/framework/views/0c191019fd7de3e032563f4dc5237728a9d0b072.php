
    <div id="container">
        <!-- Feature Box Start-->
        <div class="container">
            <div class="custom-feature-box row">
                <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="feature-box fbox_1">
                        <div class="title">ارسال رایگان</div>
                        <p>برای خرید های بیش از 500 هزار تومان</p>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="feature-box fbox_2">
                        <div class="title">assen</div>
                        <p>به زودی راه اندازی خواهد شد ...</p>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="feature-box fbox_3">
                        <div class="title">تخفیف ویژه</div>
                        <p>بهترین هدیه شما</p>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="feature-box fbox_4">
                        <div class="title">امتیازات خرید</div>
                        <p>از هر خرید امتیاز کسب کرده و از آن بهره بگیرید</p>
                    </div>
                </div>
            </div>
        </div>
        <!-- Feature Box End-->
        <div class="container">
            <div class="row">
                <!-- Left Part Start-->
                <aside id="column-left" class="col-sm-3 hidden-xs">
                    <h3 class="subtitle"> <?php echo e(__('web/public.categories')); ?></h3>
                    <div class="box-category">
                        <ul id="cat_accordion">
                            <?php $__currentLoopData = $categoriesProvider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($category->parent_id==0): ?>
                                    <li><a href="<?php echo e(route('web.show.category',$category->id)); ?>"><?php echo e(\App\Providers\MyProvider::_text($category->title)); ?>

                                            <?php if(isset($category->children[0]) and $category->children!=[]): ?></a><span class="down"></span>
                                        <ul>
                                             <?php if (isset($component)) { $__componentOriginal760d2b0009624520b77b14650e124a5fe391aae9 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\WebShowCategoriesSidebar::class, ['categories' => $category->children]); ?>
<?php $component->withName('web-show-categories-sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                                             <?php if (isset($__componentOriginal760d2b0009624520b77b14650e124a5fe391aae9)): ?>
<?php $component = $__componentOriginal760d2b0009624520b77b14650e124a5fe391aae9; ?>
<?php unset($__componentOriginal760d2b0009624520b77b14650e124a5fe391aae9); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                                        </ul>
                                        <?php else: ?>
                                        </a>
                                        <?php endif; ?>
                                    </li>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </ul>


                    </div>
                    <?php if(isset($specialProducts)): ?>
                        <h3 class="subtitle"><?php echo e(__('web/public.product_vip')); ?></h3>
                        <?php $__currentLoopData = $specialProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="side-item">
                                <div class="product-thumb clearfix">
                                    <div class="image"><a href="<?php echo e(route('web.show.product',$product->id)); ?>"><img src="<?php echo e($product->images["images"]["50"]); ?>" alt="<?php echo e(\App\Providers\MyProvider::_text($product->title)); ?>" title="<?php echo e(\App\Providers\MyProvider::_text($product->title)); ?> " class="img-responsive" /></a></div>
                                    <div class="caption">
                                        <h4><a href="<?php echo e(route('web.show.product',$product->id)); ?>"><?php echo e(\App\Providers\MyProvider::_text($product->title)); ?></a></h4>
                                        <p class="price"> <span class="price-new"><?php echo e(\App\Providers\MyProvider::exToLocalDiscount($product->price,$product->discount)); ?><?php echo e(__('web/public.currency_name_'.session('Local_Currency'))); ?></span> <?php if($product->discount>0): ?><span class="price-old"><?php echo e(\App\Providers\MyProvider::exToLocal($product->price)); ?><?php echo e(__('web/public.currency_name_'.session('Local_Currency'))); ?></span> <span class="saving">-<?php echo e($product->discount); ?>%</span> <?php endif; ?></p>
                                    </div>
                                </div>

                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>

                    <?php if(isset($newProducts)): ?>
                        <h3 class="subtitle"><?php echo e(__('web/public.product_new')); ?></h3>
                        <?php $__currentLoopData = $newProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="side-item">
                                <div class="product-thumb clearfix">
                                    <div class="image"><a href="<?php echo e(route('web.show.product',$product->id)); ?>"><img src="<?php echo e($product->images["images"]["50"]); ?>" alt="<?php echo e(\App\Providers\MyProvider::_text($product->title)); ?>" title="<?php echo e(\App\Providers\MyProvider::_text($product->title)); ?> " class="img-responsive" /></a></div>
                                    <div class="caption">
                                        <h4><a href="<?php echo e(route('web.show.product',$product->id)); ?>"><?php echo e(\App\Providers\MyProvider::_text($product->title)); ?></a></h4>
                                        <p class="price"> <span class="price-new"><?php echo e(\App\Providers\MyProvider::exToLocalDiscount($product->price,$product->discount)); ?><?php echo e(__('web/public.currency_name_'.session('Local_Currency'))); ?></span> <?php if($product->discount>0): ?><span class="price-old"><?php echo e(\App\Providers\MyProvider::exToLocal($product->price)); ?><?php echo e(__('web/public.currency_name_'.session('Local_Currency'))); ?></span> <span class="saving">-<?php echo e($product->discount); ?>%</span> <?php endif; ?></p>
                                    </div>
                                </div>

                            </div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
                </aside>
<?php /**PATH C:\Users\Mr Rezaei\Desktop\shop\resources\views/web/section/product-side.blade.php ENDPATH**/ ?>