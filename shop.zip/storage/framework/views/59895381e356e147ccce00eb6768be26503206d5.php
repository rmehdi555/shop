
<?php $__env->startSection('content'); ?>
    <div id="main-content">
        <div class="container-fluid">
            <div class="block-header">
                <div class="row">
                    <div class="col-lg-5 col-md-8 col-sm-12">
                        <h2><?php echo e(__('admin/public.product_categories_list')); ?></h2>
                    </div>
                    <div class="col-lg-7 col-md-4 col-sm-12 text-right">
                        
                            
                        
                    </div>
                </div>
            </div>




            <div class="row clearfix">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="header">
                            <h2><?php echo e(__('admin/public.product_categories_list')); ?></h2>
                        </div>
                        <div class="body">
                            
                                
                            
                            
                                
                                    
                                    
                                        
                                        
                                        
                                        
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                        
                                        
                                        
                                        
                                            
                                                    
                                            
                                                    
                                            
                                                    
                                            
                                                    
                                        
                                    
                                    
                                    
                                    


                                    
                                    
                                    
                                        
                                        
                                        
                                        
                                    
                                    
                                
                            

                            <div class="table-responsive">
                                <table class="table table-bordered table-hover js-basic-example dataTable table-custom">
                                    <thead>
                                    <tr>
                                        <th><?php echo e(__('admin/public.id')); ?></th>
                                        <th><?php echo e(__('admin/public.title')); ?></th>
                                        <th><?php echo e(__('admin/public.parent_id')); ?></th>
                                        <th><?php echo e(__('admin/public.status')); ?></th>
                                        <th><?php echo e(__('admin/public.actions')); ?></th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $allProductCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productCategories): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="gradeA">
                                            <td><?php echo e($productCategories->id); ?></td>
                                            <td><?php echo e(\App\Providers\MyProvider::_text($productCategories->title)); ?></td>
                                            <td><?php echo e($productCategories->parent_id); ?></td>
                                            <td><?php echo e($productCategories->status?__('admin/public.active'):__('admin/public.inactive')); ?></td>
                                            <td class="actions">

                                                <form action="<?php echo e(route('productCategories.destroy', $productCategories->id)); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <a href="<?php echo e(route('productCategories.show',$productCategories->id)); ?>" class="btn btn-sm btn-icon btn-pure btn-default on-default m-r-5 button-show"
                                                       data-toggle="tooltip" data-original-title="<?php echo e(__('admin/public.show')); ?>"><i class="icon-eye" aria-hidden="true"></i></a>
                                                    <a href="<?php echo e(route('productCategories.edit',$productCategories->id)); ?>" class="btn btn-sm btn-icon btn-pure btn-default on-default m-r-5 button-edit"
                                                       data-toggle="tooltip" data-original-title="<?php echo e(__('admin/public.edit')); ?>"><i class="icon-pencil" aria-hidden="true"></i></a>
                                                    <button type="submit" class="btn btn-sm btn-icon btn-pure btn-default on-default button-remove"
                                                            data-toggle="tooltip" data-original-title="<?php echo e(__('admin/public.remove')); ?>"><i class="icon-trash" aria-hidden="true"></i></button>
                                                </form>

                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                    </tbody>
                                    <tfoot>
                                    <tr>
                                        <th><?php echo e(__('admin/public.id')); ?></th>
                                        <th><?php echo e(__('admin/public.title')); ?></th>
                                        <th><?php echo e(__('admin/public.parent_id')); ?></th>
                                        <th><?php echo e(__('admin/public.status')); ?></th>
                                        <th><?php echo e(__('admin/public.actions')); ?></th>
                                    </tr>
                                    </tfoot>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Mr Rezaei\Desktop\noor\resources\views/admin/product-categories/index.blade.php ENDPATH**/ ?>