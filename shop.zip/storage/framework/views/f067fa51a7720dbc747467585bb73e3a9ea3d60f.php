
<?php $__env->startSection('content'); ?>

    <section class="bu-inner-main">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="alert alert-info m-1">
                        <p class="p-1 text-justify">معلم گرامی
                            <?php echo e($user->teacher->name); ?>  <?php echo e($user->teacher->family); ?>

                            هزینه ثبت نام در ذیل ذکر شده است ، بعد از پرداخت آن ثبت نام شما نهایی خواهد شد .
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>



    <!-- Start: Inner main -->
    <section class="bu-inner-main">
        <div class="container">

            <div class="row">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th>هزینه ثبت نام</th>
                            <th><?php echo e(\App\Providers\MyProvider::_text($siteDetailsProvider["price_register_m"]->value)); ?>(<?php echo e(__('web/public.currency_name_IRR')); ?>)</th>
                            
                        </tr>
                        </thead>

                    </table>
                </div>
            </div>
            <br><br>


            <div class="row">
                <div class="col-md-12">
                    <div class="d-flex justify-content-center mb-2 ">
                        <div class="p-2 contract-div-hide">
                            <a href="<?php echo e(route('teacher.payment.index')); ?>"
                               class="btn btn-primary"><?php echo e(__('web/public.btn_payment')); ?></a>
                        </div>
                    </div>
                </div>
            </div>





        </div>
    </section>
    <!-- Start: Inner main -->





<?php $__env->stopSection(); ?>



<?php echo $__env->make('teacher.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Mr Rezaei\Desktop\noor\resources\views/teacher/pages/status-3.blade.php ENDPATH**/ ?>