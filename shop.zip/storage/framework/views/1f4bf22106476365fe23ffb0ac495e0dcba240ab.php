<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li><a href="<?php echo e(route('web.show.category',$category->id)); ?>"><?php echo e(\App\Providers\MyProvider::_text($category->title)); ?>

            <?php if(isset($category->children[0]) and $category->children!=[]): ?></a><span class="down"></span>
            <ul>
                 <?php if (isset($component)) { $__componentOriginal760d2b0009624520b77b14650e124a5fe391aae9 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\WebShowCategoriesSidebar::class, ['categories' => $category->children]); ?>
<?php $component->withName('web-show-categories-sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                 <?php if (isset($__componentOriginal760d2b0009624520b77b14650e124a5fe391aae9)): ?>
<?php $component = $__componentOriginal760d2b0009624520b77b14650e124a5fe391aae9; ?>
<?php unset($__componentOriginal760d2b0009624520b77b14650e124a5fe391aae9); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
            </ul>
        <?php else: ?>
        </a>
        <?php endif; ?>
    </li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php /**PATH C:\Users\Mr Rezaei\Desktop\newshop\resources\views/components/web-show-categories-sidebar.blade.php ENDPATH**/ ?>