
<?php $__env->startSection('content'); ?>
    <div class="main-inner-banner">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="main-inner-banner-cont">
                        <div class="main-inner-banner-c-title">
                            <ul class="main-breadcrumb">
                                <li><a href="<?php echo e(route('web.home')); ?>">صفحه اصلی</a></li>
                                
                            </ul>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Start: Inner main -->
    <section class="bu-inner-main">
        <div class="container">
            <div class="row">
                <div class="container p-3 my-3 bg-primary text-white align-center">
                    <h1><a href="<?php echo e(\App\Providers\MyProvider::_text($siteDetailsProvider["box_fields_link"]->value)); ?>"><?php echo \App\Providers\MyProvider::_text($siteDetailsProvider["box_fields_body"]->value); ?></a></h1>
                </div>
            </div>
        </div>
    </section>
    <!-- Start: Inner main -->
    <section class="bu-inner-main">
        <div class="container">
            <div class="row">
                <?php echo \App\Providers\MyProvider::_text($siteDetailsProvider["page_fields_body"]->value); ?>

            </div>
        </div>
    </section>
    <!-- Start: Inner main -->
    <section class="bu-inner-main">
        <div class="container">
            <?php  $style=array("1"=>"list-group-item list-group-item-danger",
            "2"=>"list-group-item list-group-item-success",
            "3"=>"list-group-item list-group-item-info",
            "4"=>"list-group-item list-group-item-warning",
            "5"=>"list-group-item list-group-item-secondary",
            );
            $style2=array("1"=>"list-group-item list-group-item-light",
            "2"=>"list-group-item list-group-item-dark",
            );
            $i=1;
            ?>
            <ul class="list-group">
                <?php $__currentLoopData = $allField; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($item->parent_id==0 and !isset($item->children[1])): ?>
                        <li class="<?php echo e($style[$i%5+1]); ?>"><a href="<?php echo e(route('web.show.field',$item->id)); ?>"><?php echo e(\App\Providers\MyProvider::_text($item->title)); ?></a></li>
                        <?php
                            $i++;
                        ?>
                    <?php endif; ?>
                    <?php if($item->parent_id==0 and isset($item->children[1])): ?>
                            <li class="<?php echo e($style[$i%5+1]); ?>"><h3><i class="fa fa-arrow-left" aria-hidden="true"></i><a href="<?php echo e(route('web.show.field',$item->id)); ?>"><?php echo e(\App\Providers\MyProvider::_text($item->title)); ?></a></h3>
                            <?php
                                $y=1;
                            ?>
                            <ul class="list-group">
                                <?php $__currentLoopData = $item->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <li class="<?php echo e($style2[$y%2+1]); ?>"><a href="<?php echo e(route('web.show.field',$child->id)); ?>"><?php echo e(\App\Providers\MyProvider::_text($child->title)); ?></a></li>

                                    <?php
                                        $y++;
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </ul>
                        </li>

                        <?php
                            $i++;
                        ?>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </ul>


        </div>
    </section>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rmehdi555\Desktop\noor\resources\views/web/pages/fields.blade.php ENDPATH**/ ?>