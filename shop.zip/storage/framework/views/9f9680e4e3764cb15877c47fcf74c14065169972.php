

<?php $__env->startSection('content'); ?>




                <!-- Left Part End-->
                <!--Middle Part Start-->

                <div id="content" class="col-sm-9">
                    <!-- Slideshow Start-->
                    <div class="slideshow single-slider owl-carousel">
                        <?php $__currentLoopData = $slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $baner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="item"> <a href="<?php echo e($baner->link); ?>"><img class="img-responsive" src="<?php echo e($baner->images["images"]["920-380"]); ?>" alt="<?php echo e(\App\Providers\MyProvider::_text($baner->title)); ?>" /></a> </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <!-- Slideshow End-->
                    <!-- Featured محصولات Start-->
                    <?php if(isset($newProducts)): ?>
                        <h3 class="subtitle"><?php echo e(__('web/public.product_new')); ?></h3>
                            <div class="owl-carousel product_carousel">
                             <?php $__currentLoopData = $newProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                                    <div class="product-thumb clearfix">
                                        <div class="image"><a href="<?php echo e(route('web.show.product',$product->id)); ?>"><img src="<?php echo e($product->images["images"]["200"]); ?>" alt="<?php echo e(\App\Providers\MyProvider::_text($product->title)); ?>" title="<?php echo e(\App\Providers\MyProvider::_text($product->title)); ?>" class="img-responsive" /></a></div>
                                        <div class="caption">
                                            <h4><a href="<?php echo e(route('web.show.product',$product->id)); ?>"><?php echo e(\App\Providers\MyProvider::_text($product->title)); ?></a></h4>
                                            <p class="price"> <span class="price-new"><?php echo e(\App\Providers\MyProvider::exToLocalDiscount($product->price,$product->discount)); ?><?php echo e(__('web/public.currency_name_'.session('Local_Currency'))); ?></span><br> <?php if($product->discount>0): ?><span class="price-old"><?php echo e(\App\Providers\MyProvider::exToLocal($product->price)); ?><?php echo e(__('web/public.currency_name_'.session('Local_Currency'))); ?></span> <span class="saving">-<?php echo e($product->discount); ?>%</span> <?php endif; ?></p>
                                            <div class="rating"> <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span> <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span> <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span> <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span> <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span> </div>
                                        </div>
                                        <div class="button-group">
                                            <button class="btn-primary" type="button" onClick="cart.add('46');"><span><?php echo e(__('web/public.add_cart')); ?></span></button>
                                            
                                                
                                                
                                            
                                        </div>
                                    </div>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>

                    <?php endif; ?>

                    <?php if(isset($specialProducts)): ?>
                        <h3 class="subtitle"><?php echo e(__('web/public.product_vip')); ?></h3>
                        <div class="owl-carousel product_carousel">
                            <?php $__currentLoopData = $specialProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                                <div class="product-thumb clearfix">
                                    <div class="image"><a href="<?php echo e(route('web.show.product',$product->id)); ?>"><img src="<?php echo e($product->images["images"]["200"]); ?>" alt="<?php echo e(\App\Providers\MyProvider::_text($product->title)); ?>" title="<?php echo e(\App\Providers\MyProvider::_text($product->title)); ?>" class="img-responsive" /></a></div>
                                    <div class="caption">
                                        <h4><a href="<?php echo e(route('web.show.product',$product->id)); ?>"><?php echo e(\App\Providers\MyProvider::_text($product->title)); ?></a></h4>
                                        <p class="price"> <span class="price-new"><?php echo e(\App\Providers\MyProvider::exToLocalDiscount($product->price,$product->discount)); ?><?php echo e(__('web/public.currency_name_'.session('Local_Currency'))); ?></span><br> <?php if($product->discount>0): ?><span class="price-old"><?php echo e(\App\Providers\MyProvider::exToLocal($product->price)); ?><?php echo e(__('web/public.currency_name_'.session('Local_Currency'))); ?></span> <span class="saving">-<?php echo e($product->discount); ?>%</span> <?php endif; ?></p>
                                        <div class="rating"> <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span> <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span> <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span> <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span> <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span> </div>
                                    </div>
                                    <div class="button-group">
                                        <button class="btn-primary" type="button" onClick="cart.add('46');"><span><?php echo e(__('web/public.add_cart')); ?></span></button>
                                        
                                            
                                            
                                        
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                    <?php endif; ?>


                    <!-- Brand محصولات Slider End -->
                    <!-- Brand Logo Carousel Start-->
                    <div id="carousel" class="owl-carousel nxt">
                        <div class="item text-center"> <a href="#"><img src="image/product/apple_logo-100x100.jpg" alt=" میلگرد نیشابور" class="img-responsive" /></a> </div>
                        <div class="item text-center"> <a href="#"><img src="image/product/canon_logo-100x100.jpg" alt="میلگرد ظفر بناب" class="img-responsive" /></a> </div>
                        <div class="item text-center"> <a href="#"><img src="image/product/apple_logo-100x100.jpg" alt="میلگرد ذوب آهن اصفهان" class="img-responsive" /></a> </div>
                        <div class="item text-center"> <a href="#"><img src="image/product/canon_logo-100x100.jpg" alt="میلگرد میانه" class="img-responsive" /></a> </div>
                        <div class="item text-center"> <a href="#"><img src="image/product/apple_logo-100x100.jpg" alt="میلگرد ابهر" class="img-responsive" /></a> </div>
                        <div class="item text-center"> <a href="#"><img src="image/product/canon_logo-100x100.jpg" alt="میلگرد امیرکبیر" class="img-responsive" /></a> </div>

                    </div>
                    <!-- Brand Logo Carousel End -->
                </div>
                <!--Middle Part End-->
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.master-product', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Mr Rezaei\Desktop\newshop\resources\views/web/pages/index.blade.php ENDPATH**/ ?>