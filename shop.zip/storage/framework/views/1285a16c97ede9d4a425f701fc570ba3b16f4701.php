<!--Footer Start-->
<footer id="footer">
    <div class="fpart-first">
        <div class="container">
            <div class="row">
                <div class="contact col-lg-6 col-md-6 col-sm-12 col-xs-12">
                    <h5><?php echo e(__('web/public.contact_us')); ?></h5>
                    <ul>
                        <li class="address"><i class="fa fa-map-marker"></i><?php echo e(\App\Providers\MyProvider::_text($siteDetailsProvider["address"]->value)); ?></li>
                        <li class="mobile"><i class="fa fa-phone"></i><?php echo e(\App\Providers\MyProvider::_text($siteDetailsProvider["phone"]->value)); ?></li>
                        <li class="mobile"><i class="fa fa-phone"></i><?php echo e(\App\Providers\MyProvider::_text($siteDetailsProvider["mobile"]->value)); ?></li>
                        <li class="email"><i class="fa fa-envelope"></i><?php echo e(\App\Providers\MyProvider::_text($siteDetailsProvider["email"]->value)); ?></li>
                    </ul>
                </div>
                <div class="column col-lg-3 col-md-3 col-sm-3 col-xs-12">
                    <h5><?php echo e(__('web/public.links')); ?></h5>
                    <ul>
                        <?php $__currentLoopData = $webMenusFooter1Provider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a href="<?php echo e($item->link); ?>"><?php echo e(\App\Providers\MyProvider::_text($item->title)); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <div class="column col-lg-3 col-md-3 col-sm-3 col-xs-12">
                    <h5><?php echo e(__('web/public.user_service')); ?></h5>
                    <ul>
                        <?php $__currentLoopData = $webMenusFooter2Provider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a href="<?php echo e($item->link); ?>"><?php echo e(\App\Providers\MyProvider::_text($item->title)); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <ali><a referrerpolicy="origin" target="_blank" href="https://trustseal.enamad.ir/?id=202090&amp;Code=zWSOD2mavOWNwYYvBijv"><img referrerpolicy="origin" src="https://Trustseal.eNamad.ir/logo.aspx?id=202090&amp;Code=zWSOD2mavOWNwYYvBijv" alt="اینماد" style="cursor:pointer" id="zWSOD2mavOWNwYYvBijv"></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="fpart-second">
        <div class="container">
            <div id="powered" class="clearfix">
                <div class="powered_text pull-left flip">
                    <p>کپی رایت © 2021 فروشگاه شما |ایجاد توسط <a href="https://rmehdi555.ir" target="_blank">555</a></p>
                </div>
                
            
            
                
                    
                
                
            
        </div>
    </div>
    <div id="back-top"><a data-toggle="tooltip" title="بازگشت به بالا" href="javascript:void(0)" class="backtotop"><i class="fa fa-chevron-up"></i></a></div>
</footer>
<!--Footer End-->

</div><?php /**PATH C:\Users\Mr Rezaei\Desktop\shop\resources\views/web/section/footer.blade.php ENDPATH**/ ?>