<div id="leftsidebar" class="sidebar">
    <?php if(!isset($SID)): ?>
        <?php echo e($SID=100); ?>

    <?php endif; ?>
        <div class="slimScrollDiv" style="position: relative; overflow: hidden; width: auto; height: calc(100vh - 65px);"><div class="sidebar-scroll" style="overflow: hidden; width: auto; height: calc(100vh - 65px);">
            <nav id="leftsidebar-nav" class="sidebar-nav">
                <ul id="main-menu" class="metismenu">
                    <li class="heading"><?php echo e(__('admin/public.main')); ?></li>
                    <li><a href="<?php echo e(route('admin.panel')); ?>"><i class="icon-home"></i><span><?php echo e(__('admin/public.dashboard')); ?></span></a></li>
                    
                    
                    
                    
                    
                    
                    <li class="<?php if($SID>=10 and $SID<20): ?> active <?php endif; ?>">
                        <a href="#news_categories" class="has-arrow"><i class="icon-diamond"></i><span><?php echo e(__('admin/public.news_categories')); ?></span></a>
                        <ul aria-expanded="false" class="collapse">
                            <li class="<?php if($SID==10 ): ?> active <?php endif; ?>"><a href="<?php echo e(route('newsCategories.index',['SID' => '10'])); ?>"><?php echo e(__('admin/public.news_categories_list')); ?></a></li>
                            <li class="<?php if($SID==11 ): ?> active <?php endif; ?>"><a href="<?php echo e(route('newsCategories.create',['SID' => '11'])); ?>"><?php echo e(__('admin/public.news_categories_add')); ?></a></li>
                        </ul>
                    </li>
                    <li class="<?php if($SID>=20 and $SID<30): ?> active <?php endif; ?>">
                        <a href="#news" class="has-arrow"><i class="icon-diamond"></i><span><?php echo e(__('admin/public.news')); ?></span></a>
                        <ul aria-expanded="false" class="collapse">
                            <li class="<?php if($SID==20 ): ?> active <?php endif; ?>"><a href="<?php echo e(route('news.index',['SID' => '20'])); ?>"><?php echo e(__('admin/public.news_list')); ?></a></li>
                            <li class="<?php if($SID==21 ): ?> active <?php endif; ?>"><a href="<?php echo e(route('news.create',['SID' => '21'])); ?>"><?php echo e(__('admin/public.news_add')); ?></a></li>
                        </ul>
                    </li>
                    <li class="<?php if($SID>=30 and $SID<40): ?> active <?php endif; ?>">
                        <a href="#news" class="has-arrow"><i class="icon-diamond"></i><span><?php echo e(__('admin/public.fields')); ?></span></a>
                        <ul aria-expanded="false" class="collapse">
                            <li class="<?php if($SID==30 ): ?> active <?php endif; ?>"><a href="<?php echo e(route('fields.index',['SID' => '30'])); ?>"><?php echo e(__('admin/public.fields_list')); ?></a></li>
                            <li class="<?php if($SID==31 ): ?> active <?php endif; ?>"><a href="<?php echo e(route('fields.create',['SID' => '31'])); ?>"><?php echo e(__('admin/public.fields_add')); ?></a></li>
                        </ul>
                    </li>



                    <li class="<?php if($SID>=100 and $SID<200): ?> active <?php endif; ?>">
                        <a href="#slider" class="has-arrow"><i class="icon-diamond"></i><span><?php echo e(__('admin/public.slider')); ?></span></a>
                        <ul aria-expanded="false" class="collapse">
                            <li class="<?php if($SID==100 ): ?> active <?php endif; ?>"><a href="<?php echo e(route('slider.index',['SID' => '100'])); ?>"><?php echo e(__('admin/public.slider_list')); ?></a></li>
                            <li class="<?php if($SID==101 ): ?> active <?php endif; ?>"><a href="<?php echo e(route('slider.create',['SID' => '101'])); ?>"><?php echo e(__('admin/public.slider_add')); ?></a></li>
                        </ul>
                    </li>
                    <li class="<?php if($SID>=200 and $SID<300): ?> active <?php endif; ?>">
                        <a href="#products" class="has-arrow"><i class="icon-diamond"></i><span><?php echo e(__('admin/public.products')); ?></span></a>
                        <ul aria-expanded="false" class="collapse">
                            <li class="<?php if($SID==200 ): ?> active <?php endif; ?>"><a href="<?php echo e(route('products.index',['SID' => '200'])); ?>"><?php echo e(__('admin/public.products_list')); ?></a></li>
                            <li class="<?php if($SID==201 ): ?> active <?php endif; ?>"><a href="<?php echo e(route('products.create',['SID' => '201'])); ?>"><?php echo e(__('admin/public.product_add')); ?></a></li>
                        </ul>
                    </li>

                    <li class="<?php if($SID>=300 and $SID<400): ?> active <?php endif; ?>">
                        <a href="#product_categories" class="has-arrow"><i class="icon-diamond"></i><span><?php echo e(__('admin/public.product_categories')); ?></span></a>
                        <ul aria-expanded="false" class="collapse">
                            <li class="<?php if($SID==300 ): ?> active <?php endif; ?>"><a href="<?php echo e(route('productCategories.index',['SID' => '300'])); ?>"><?php echo e(__('admin/public.product_categories_list')); ?></a></li>
                            <li class="<?php if($SID==301 ): ?> active <?php endif; ?>"><a href="<?php echo e(route('productCategories.create',['SID' => '301'])); ?>"><?php echo e(__('admin/public.product_categories_add')); ?></a></li>
                        </ul>
                    </li>


                    <li class="<?php if($SID>=400 and $SID<500): ?> active <?php endif; ?>">
                        <a href="#page" class="has-arrow"><i class="icon-diamond"></i><span><?php echo e(__('admin/public.web_pages')); ?></span></a>
                        <ul aria-expanded="false" class="collapse">
                            <li class="<?php if($SID==400 ): ?> active <?php endif; ?>"><a href="<?php echo e(route('webPages.index',['SID' => '400'])); ?>"><?php echo e(__('admin/public.web_pages_list')); ?></a></li>
                            <li class="<?php if($SID==401 ): ?> active <?php endif; ?>"><a href="<?php echo e(route('webPages.create',['SID' => '401'])); ?>"><?php echo e(__('admin/public.web_pages_add')); ?></a></li>
                        </ul>
                    </li>

                    <li class="<?php if($SID>=500 and $SID<600): ?> active <?php endif; ?>">
                        <a href="#menus" class="has-arrow"><i class="icon-diamond"></i><span><?php echo e(__('admin/public.menus')); ?></span></a>
                        <ul aria-expanded="false" class="collapse">
                            <li class="<?php if($SID==500 ): ?> active <?php endif; ?>"><a href="<?php echo e(route('menus.index',['SID' => '500'])); ?>"><?php echo e(__('admin/public.menus_list')); ?></a></li>
                            <li class="<?php if($SID==501 ): ?> active <?php endif; ?>"><a href="<?php echo e(route('menus.create',['SID' => '501'])); ?>"><?php echo e(__('admin/public.menus_add')); ?></a></li>
                        </ul>
                    </li>

                    <li class="<?php if($SID>=700 and $SID<800): ?> active <?php endif; ?>">
                        <a href="#menu_categories" class="has-arrow"><i class="icon-diamond"></i><span><?php echo e(__('admin/public.menu_categories')); ?></span></a>
                        <ul aria-expanded="false" class="collapse">
                            <li class="<?php if($SID==700 ): ?> active <?php endif; ?>"><a href="<?php echo e(route('menuCategories.index',['SID' => '700'])); ?>"><?php echo e(__('admin/public.menu_categories_list')); ?></a></li>
                            <li class="<?php if($SID==701 ): ?> active <?php endif; ?>"><a href="<?php echo e(route('menuCategories.create',['SID' => '701'])); ?>"><?php echo e(__('admin/public.menu_categories_add')); ?></a></li>
                        </ul>
                    </li>




                    <li class="<?php if($SID>=900 and $SID<1000): ?> active <?php endif; ?>">
                        <a href="#site-setting" class="has-arrow"><i class="icon-diamond"></i><span><?php echo e(__('admin/public.site_settings')); ?></span></a>
                        <ul aria-expanded="false" class="collapse">
                            <li class="<?php if($SID==900 ): ?> active <?php endif; ?>"><a href="<?php echo e(route('siteDetails.index',['SID' => '900'])); ?>"><?php echo e(__('admin/public.site_settings_list')); ?></a></li>
                            <li class="<?php if($SID==901 ): ?> active <?php endif; ?>"><a href="<?php echo e(route('siteDetails.create',['SID' => '901'])); ?>"><?php echo e(__('admin/public.site_settings_add')); ?></a></li>
                            <li class="<?php if($SID==902 ): ?> active <?php endif; ?>"><a href="<?php echo e(route('contactUs.index',['SID' => '902'])); ?>"><?php echo e(__('admin/public.contact_us_list')); ?></a></li>
                            <li class="<?php if($SID==903 ): ?> active <?php endif; ?>"><a href="<?php echo e(route('complaint.index',['SID' => '903'])); ?>"><?php echo e(__('admin/public.complaint_list')); ?></a></li>
                        </ul>
                    </li>


                </ul>
            </nav>
        </div><div class="slimScrollBar" style="background: rgb(239, 239, 239); width: 2px; position: absolute; top: 0px; opacity: 0.4; display: none; border-radius: 3px; z-index: 99; right: 1px; height: 37.3737px;"></div><div class="slimScrollRail" style="width: 2px; height: 100%; position: absolute; top: 0px; display: none; border-radius: 7px; background: rgb(51, 51, 51); opacity: 0.2; z-index: 90; right: 1px;"></div></div>
    </div><?php /**PATH C:\Users\rmehdi555\Desktop\noor\resources\views/admin/section/left-sidebar.blade.php ENDPATH**/ ?>