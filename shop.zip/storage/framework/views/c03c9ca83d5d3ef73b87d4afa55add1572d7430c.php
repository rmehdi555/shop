<?php if(isset($category->products[0]) and $category->products!=[]): ?>
    <?php $__currentLoopData = $category->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


        <div class="product-layout product-list col-xs-12">
            <div class="product-thumb">
                <div class="image"><a href="<?php echo e(route('web.show.product',$product->id)); ?>"><img src="<?php echo e($product->images["images"]["200"]); ?>" alt="<?php echo e(\App\Providers\MyProvider::_text($product->title)); ?>" title="<?php echo e(\App\Providers\MyProvider::_text($product->title)); ?>" class="img-responsive" /></a></div>
                <div>
                    <div class="caption">
                        <h4><a href="<?php echo e(route('web.show.product',$product->id)); ?>"><?php echo e(\App\Providers\MyProvider::_text($product->title)); ?></a></h4>
                        <p class="description"><?php echo e(\App\Providers\MyProvider::_text($product->description)); ?></p>
                        <p class="price"> <span class="price-new"><?php echo e(\App\Providers\MyProvider::exToLocalDiscount($product->price,$product->discount)); ?><?php echo e(__('web/public.currency_name_'.session('Local_Currency'))); ?></span><br> <?php if($product->discount>0): ?><span class="price-old"><?php echo e(\App\Providers\MyProvider::exToLocal($product->price)); ?><?php echo e(__('web/public.currency_name_'.session('Local_Currency'))); ?></span> <span class="saving">-<?php echo e($product->discount); ?>%</span> <?php endif; ?></p>

                    </div>
                    <div class="button-group">
                        <button class="btn-primary" type="button" onClick=""><span><?php echo e(__('web/public.add_cart')); ?></span></button>
                        
                            
                            
                        
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
    <?php if(isset($category->children[0]) and $category->children!=[]): ?>
        <?php $__currentLoopData = $category->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

             <?php if (isset($component)) { $__componentOriginalbae54de957b56aad9bacf8dfbd034db2691e8198 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\WebShowProductInCategory::class, ['category' => $category]); ?>
<?php $component->withName('web-show-product-in-category'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
             <?php if (isset($__componentOriginalbae54de957b56aad9bacf8dfbd034db2691e8198)): ?>
<?php $component = $__componentOriginalbae54de957b56aad9bacf8dfbd034db2691e8198; ?>
<?php unset($__componentOriginalbae54de957b56aad9bacf8dfbd034db2691e8198); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php endif; ?>


<?php /**PATH C:\Users\Mr Rezaei\Desktop\newshop\resources\views/components/web-show-product-in-category.blade.php ENDPATH**/ ?>