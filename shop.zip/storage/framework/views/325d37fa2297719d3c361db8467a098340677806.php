
<?php $__env->startSection('content'); ?>

    <div id="container">
        <div class="container">
            
                
                
                    
                                                                        
                                    
                    
                                                                            
                                    
                    
                
            
            <!-- Breadcrumb End-->
            <div class="row">
                <!--Middle Part Start-->
                <div id="content" class="col-sm-9">
                    444
                </div>
            </div>
            <!--Middle Part End -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Mr Rezaei\Desktop\noor\resources\views/user/pages/panel.blade.php ENDPATH**/ ?>