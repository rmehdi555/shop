
<?php $__env->startSection('content'); ?>

    <div id="container">
        <div class="container">
            <!-- Breadcrumb Start-->
            
                
                
                
            
            <!-- Breadcrumb End-->
            <div class="row">
                <!--Middle Part Start-->
                <div id="content" class="col-sm-9">
                    <div itemscope itemtype="">
                        <h1 class="title" itemprop="name"><?php echo e(\App\Providers\MyProvider::_text($product->title)); ?></h1>
                        <div class="row product-info">
                            <div class="col-sm-6">
                                <div class="image"><img class="img-responsive" itemprop="image" id="zoom_01" src="<?php echo e($product->images["images"]["350"]); ?>" title="<?php echo e(\App\Providers\MyProvider::_text($product->title)); ?>" alt="<?php echo e(\App\Providers\MyProvider::_text($product->title)); ?>" data-zoom-image="<?php echo e($product->images["images"]["500"]); ?>" /> </div>
                                <div class="center-block text-center"><span class="zoom-gallery"><i class="fa fa-search"></i> <?php echo e(__('web/public.click_on_image_for_zoom')); ?> </span></div>
                                <div class="image-additional" id="gallery_01"> <a class="thumbnail" href="#" data-zoom-image="<?php echo e($product->images["images"]["500"]); ?>" data-image="<?php echo e($product->images["images"]["350"]); ?>" title="لپ تاپ ایلین ور"> <img src="<?php echo e($product->images["images"]["66"]); ?>" title="لپ تاپ ایلین ور" alt = "لپ تاپ ایلین ور"/></a></div>
                                

                            </div>
                            <div class="col-sm-6">
                                <ul class="list-unstyled description">
                                    <li><b><?php echo e(__('web/public.title')); ?> :</b> <a href="<?php echo e(route('web.show.product',$product->id)); ?>"><span itemprop="brand"><?php echo e(\App\Providers\MyProvider::_text($product->title)); ?></span></a></li>
                                    <li><b><?php echo e(__('web/public.id')); ?> :</b> <span itemprop="mpn"><?php echo e(\App\Providers\MyProvider::_text($product->id)); ?></span></li>
                                    <li><b><?php echo e(__('web/public.description')); ?> :</b> <?php echo \App\Providers\MyProvider::_text($product->description); ?></li>
                                    <li><b><?php echo e(__('web/public.body')); ?> :</b> <span class=""><?php echo \App\Providers\MyProvider::_text($product->body); ?></span></li>
                                </ul>
                                <ul class="price-box">
                                    <li class="price" itemprop="offers" itemscope itemtype="#"><?php if($product->discount>0): ?><span class="price-old"><?php echo e(\App\Providers\MyProvider::exToLocal($product->price)); ?><?php echo e(__('web/public.currency_name_'.session('Local_Currency'))); ?></span>  <?php endif; ?> <span itemprop="price"><?php echo e(\App\Providers\MyProvider::exToLocalDiscount($product->price,$product->discount)); ?><?php echo e(__('web/public.currency_name_'.session('Local_Currency'))); ?><span itemprop="availability" content="موجود"></span></span></li>

                                    <li></li>
                                    
                                </ul>
                                <div id="product">
                                    <h3 class="subtitle">انتخاب های در دسترس</h3>
                                    
                                        
                                        
                                            
                                            
                                            
                                            
                                            
                                        
                                    
                                    <div class="cart">
                                        <div>
                                            
                                                
                                                
                                                
                                                
                                                
                                            
                                            <button type="button" id="button-cart" class="btn btn-primary btn-lg"> <?php echo e(__('web/public.add_cart')); ?></button>
                                        </div>
                                        
                                            
                                            
                                            
                                        
                                    </div>
                                </div>
                                
                                    
                                    
                                
                                
                                <!-- AddThis Button BEGIN -->
                                
                                
                                <!-- AddThis Button END -->
                            </div>
                        </div>
                        <ul class="nav nav-tabs">
                            <li class="active"><a href="#tab-description" data-toggle="tab"><?php echo e(__('web/public.body')); ?></a></li>
                            
                            
                        </ul>
                        <div class="tab-content">
                            <div itemprop="description" id="tab-description" class="tab-pane active">
                                <div>
                                    <?php echo \App\Providers\MyProvider::_text($product->body); ?>

                                </div>
                            </div>
                            <div id="tab-specification" class="tab-pane">

                            </div>
                            <div id="tab-review" class="tab-pane">

                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--Middle Part End -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.master-product', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Mr Rezaei\Desktop\shop\resources\views/web/pages/product.blade.php ENDPATH**/ ?>