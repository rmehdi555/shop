
<?php $__env->startSection('content'); ?>
    <div class="main-inner-banner">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="main-inner-banner-cont">
                        <div class="main-inner-banner-c-title">
                            <ul class="main-breadcrumb">
                                <li><a href="<?php echo e(route('web.home')); ?>"><?php echo e(__('web/public.home_page')); ?></a></li>
                                
                            </ul>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Start: Inner main -->
    <section class="bu-inner-main">
        <div class="container">

            <div class="row">
                <!--Middle Part Start-->
                <div id="content" class="col-sm-12">
                    <h1 class="title-404 text-center">404</h1>
                    <p class="text-center lead"><?php echo e(__('web/messages.404_1')); ?><br>
                        <?php echo e(__('web/messages.404_2')); ?> </p>
                    <div class="buttons text-center"><a class="btn btn-primary btn-lg"
                                                        href="<?php echo e(route('web.index')); ?>"> <?php echo e(__('web/public.continuation')); ?></a>
                    </div>
                </div>
                <!--Middle Part End -->
            </div>


        </div>
    </section>
    <!-- Start: Inner main -->





<?php $__env->stopSection(); ?>



<?php echo $__env->make('web.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Mr Rezaei\Desktop\noor\resources\views/web/pages/404.blade.php ENDPATH**/ ?>