
<?php $__env->startSection('content'); ?>
    <div class="main-inner-banner">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="main-inner-banner-cont">
                        <div class="main-inner-banner-c-title">
                            <ul class="main-breadcrumb">
                                <li><a href="<?php echo e(route('web.home')); ?>">صفحه اصلی</a></li>
                                
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Start: Inner main -->
    <section class="bu-inner-main">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="bu-inner-main-cont">
                        <?php echo \App\Providers\MyProvider::_text($page->body); ?>

                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Start: Inner main -->



<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Mr Rezaei\Desktop\noor\resources\views/web/pages/page.blade.php ENDPATH**/ ?>