
<?php $__env->startSection('content'); ?>
    <div class="main-inner-banner">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="main-inner-banner-cont">
                        <div class="main-inner-banner-c-title">
                            <ul class="main-breadcrumb">
                                <li><a href="<?php echo e(route('web.home')); ?>"><?php echo e(__('web/public.home_page')); ?></a></li>
                                
                            </ul>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <section class="bu-inner-main">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="alert alert-info m-1">

                        <p class="p-1 text-justify">
                            متسابق گرامی شما میتوانید هردو مسابقه را شرکت نمایید به این صورت که تیک هر دو مسابقه را فعال و مشخصات خود را وارد نمایید ، سپس ابتدا آزمون کتاب خوانی که تا ساعت 10:30 وقت دارین انجام خواهد شد و بعد از آن آزمون نقاشی .
                        </p>
                        <p class="p-1 text-justify">
                            * بعد از آزمون فرم نظر سنجی وجود دارد ، با نظرات خود ما را یاری نمایید .
                        </p>
                        <p class="p-1 text-justify">
                            * در صورتی که ابتدا یکی از آزمون هارا انجام دادید برای آزمون دیگر میتوانید به همین صفحه مراجعه و تیک آزمون مد نظر را انتخاب نمایید .
                        </p>
                        <p class="p-1 text-justify">
                            * هر آزمون تنها یک بار میتوانید شرکت نمایید لذا با دقت به موارد خواسته شده جواب دهید .
                        </p>

                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Start: Inner main -->



    <!-- Start: Inner main -->
    <section class="bu-inner-main">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="bu-inner-main-form">
                        <?php if(count($errors) > 0): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        <form class="form-horizontal" id="form-level-1-save" method="POST"
                              action="<?php echo e(route('web.mosabeghe.javab.login.check')); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="row">

                                <div class="col-md-12 padding-top-15">
                                    <label class="col-md-9 col-sm-9 control-label"
                                           for="phone_1">بخشهایی که میخواهید شرکت کنید را انتخاب نمایید : <span class="required">*</span></label>
                                    <div class="col-md-10 col-sm-9 padding-top-15">
                                        <label class="form-check-inline">
                                            <input type="checkbox" name="type[]"
                                                   value="کتاب خوانی"
                                                   checked>کتاب خوانی
                                        </label>
                                        <label class="form-check-inline">
                                            <input type="checkbox"
                                                   name="type[]"
                                                   value="هنرنمایی در قاب نقاشی"
                                                   checked>هنرنمایی در قاب نقاشی
                                        </label>
                                        <?php $__errorArgs = ['class_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>





                                <div class="col-md-6 padding-top-15">
                                    <label class="col-md-6 col-sm-6 control-label"
                                           for="f_name">کد ادمین جهت تست : <span
                                                class="required">*</span></label>
                                    <div class="col-md-12 col-sm-10">
                                        <input type="text" name="key555" id="key555" value="<?php echo e(old('key555')); ?>"
                                               class="form-control  <?php $__errorArgs = ['key555'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"/>
                                    </div>
                                </div>





                            </div>
                            <div class="row">
                                <div class="col-md-6 padding-top-15">
                                    <label class="col-md-6 col-sm-6 control-label"
                                           for="meli_number"><?php echo e(__('web/public.meli_number')); ?> : <span
                                                class="required">*</span> </label>
                                    <div class="col-md-12 col-sm-10">
                                        <input type="number" pattern="[0-9]{10}" maxlength="10" minlength="10"
                                               name="meli_number" id="meli_number"
                                               value="<?php echo e(old('meli_number')); ?>"
                                               class="form-control  <?php $__errorArgs = ['meli_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                               required/>
                                        <span>کد ملی ثبت نام کننده .</span>
                                        <?php $__errorArgs = ['meli_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-6 padding-top-15">
                                    <label class="col-md-6 col-sm-6 control-label"
                                           for="f_name">کد ثبت نامی : <span
                                            class="required">*</span></label>
                                    <div class="col-md-12 col-sm-10">
                                        <input type="number" name="id" id="id" value="<?php echo e(old('id')); ?>"
                                               class="form-control  <?php $__errorArgs = ['id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"/>
                                        <span> کد ثبت نامی مسابقه که برایتان پیامک شده.</span>
                                        <?php $__errorArgs = ['id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                                        <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                            </div>


                            <br><br>

                            <div class="d-flex justify-content-center mb-2">

                                <div class="p-2 ">
                                    <button type="submit" class="btn btn-primary">ورود</button>
                                </div>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Start: Inner main -->





<?php $__env->stopSection(); ?>



<?php echo $__env->make('web.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Mr Rezaei\Desktop\noor\resources\views/web/pages/mosabeghe-javab-login.blade.php ENDPATH**/ ?>