
    <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><a href="<?php echo e($menu->link); ?>"><?php echo e(\App\Providers\MyProvider::_text($menu->title)); ?></a></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php /**PATH C:\Users\Mr Rezaei\Desktop\noor\resources\views/components/web-show-menus.blade.php ENDPATH**/ ?>