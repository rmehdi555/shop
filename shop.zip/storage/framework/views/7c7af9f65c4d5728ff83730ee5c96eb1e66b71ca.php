
<?php $__env->startSection('content'); ?>

    <!--Middle Part Start-->
    <div id="content" class="col-sm-9">
        <h1 class="title"><?php echo e(\App\Providers\MyProvider::_text($category->title)); ?></h1>

        <div class="product-filter">
            <div class="row">
                <div class="col-md-4 col-sm-5">
                    <div class="btn-group">
                        <button type="button" id="list-view" class="btn btn-default" data-toggle="tooltip" title="List"><i class="fa fa-th-list"></i></button>
                        <button type="button" id="grid-view" class="btn btn-default" data-toggle="tooltip" title="Grid"><i class="fa fa-th"></i></button>
                    </div>
                    
                </div>
                
                    
                
                
                    
                        
                        
                        
                        
                        
                        
                        
                        
                        
                    
                
                
                    
                
                
                    
                        
                        
                        
                        
                        
                    
                
            </div>
        </div>
        <br />

        <div class="row products-category">
             <?php if (isset($component)) { $__componentOriginalbae54de957b56aad9bacf8dfbd034db2691e8198 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\WebShowProductInCategory::class, ['category' => $category]); ?>
<?php $component->withName('web-show-product-in-category'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
             <?php if (isset($__componentOriginalbae54de957b56aad9bacf8dfbd034db2691e8198)): ?>
<?php $component = $__componentOriginalbae54de957b56aad9bacf8dfbd034db2691e8198; ?>
<?php unset($__componentOriginalbae54de957b56aad9bacf8dfbd034db2691e8198); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
        </div>




        <div class="row">
            <div class="col-sm-6 text-left">
                <ul class="pagination">
                    <li class="active"><span>1</span></li>
                    <li><a href="#">2</a></li>
                    <li><a href="#">&gt;</a></li>
                    <li><a href="#">&gt;|</a></li>
                </ul>
            </div>
            <div class="col-sm-6 text-right">نمایش 1 تا 12 از 15 (مجموع 2 صفحه)</div>
        </div>
    </div>
    <!--Middle Part End -->
    </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.master-product', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Mr Rezaei\Desktop\newshop\resources\views/web/pages/category.blade.php ENDPATH**/ ?>