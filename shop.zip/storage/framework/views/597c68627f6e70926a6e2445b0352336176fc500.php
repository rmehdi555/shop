<div class="main-inner-banner noPrint">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="main-inner-banner-cont">
                    <div class="main-inner-banner-c-title">
                        <ul class="main-breadcrumb">
                            <li><a href="<?php echo e(route('web.home')); ?>"><?php echo e(__('web/public.home_page')); ?></a></li>
                            
                        </ul>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<?php /**PATH C:\Users\Mr Rezaei\Desktop\noor\resources\views/student/section/user-side.blade.php ENDPATH**/ ?>