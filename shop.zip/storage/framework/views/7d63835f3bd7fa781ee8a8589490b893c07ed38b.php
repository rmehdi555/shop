<?php

use Illuminate\Support\Facades\App;

$locale = App::getLocale();
?>
<!DOCTYPE html>
<html dir="<?php if($locale=="fa"): ?> rtl <?php else: ?> ltr <?php endif; ?>">
<head>
    <!-- Meta Tags -->
    <meta charset="UTF-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link href="<?php echo e(asset('web/2020/image/favicon.png" rel="icon')); ?>" />
    <meta http-equiv="Content-Type" content="text/html" charset="UTF-8"/>
    <meta name="description" content="noor"/>
    <meta name="viewport" content="width=device-width, initial-scale=1"/>

    <meta name="theme-color" content="#3e42e9">

    
    
    
    

    <meta name="apple-mobile-web-app-title" content="site">
    

    <meta name="msapplication-TileColor" content="#3e42e9">
    

    <!-- Title -->
    <title><?php echo e(\App\Providers\MyProvider::_text($siteDetailsProvider["site_name"]->value)); ?></title>

    <!-- Shiv -->
    <!--[if lte IE 9]
    <script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->

    <!-- Stylesheets -->
    <link type="text/css" href="<?php echo e(asset('web/2020/assets/css/normalize.css" rel="stylesheet')); ?>" />
    <link type="text/css" href="<?php echo e(asset('web/2020/assets/fonts/fontawesome/css/fontawesome-all.min.css')); ?>" rel="stylesheet">
    <link type="text/css" href="<?php echo e(asset('web/2020/assets/fonts/rtl/IRANYekan/css/iranyekan.css')); ?>" rel="stylesheet" />
    <link type="text/css" href="<?php echo e(asset('web/2020/assets/fonts/ltr/Poppins/css/poppins.css')); ?>" rel="stylesheet" />
    <link type="text/css" href="<?php echo e(asset('web/2020/assets/plg/bootstrap-4.3.1/css/bootstrap.min.css')); ?>" rel="stylesheet" />
    <link type="text/css" href="<?php echo e(asset('web/2020/assets/plg/Bootstrap-Offcanvas-master/css/bootstrap.offcanvas.min.css')); ?>" rel="stylesheet" />
    <link type="text/css" href="<?php echo e(asset('web/2020/assets/plg/OwlCarousel2-2.3.4/css/owl.carousel.min.css')); ?>" rel="stylesheet" />
    <link type="text/css" href="<?php echo e(asset('web/2020/assets/plg/OwlCarousel2-2.3.4/css/owl.theme.default.min.css')); ?>" rel="stylesheet" />

    <!-- Main Stylesheet -->
    <link type="text/css" href="<?php echo e(asset('web/2020/assets/css/style.css')); ?>" rel="stylesheet" />

    <!-- JavaScript -->
    <script type="text/javascript" src="<?php echo e(asset('web/2020/assets/js/jquery-3.3.1.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('web/2020/assets/js/jquery-migrate-1.4.1.min.js')); ?>"></script>

    <script src="<?php echo e(asset('web/2020/assets/js/sweetalert.min.js')); ?>"></script>




    <!-- CSS Part End-->
    <?php if($locale=="fa"): ?>

        <?php endif; ?>
</head><?php /**PATH C:\Users\rmehdi555\Desktop\noor\resources\views/web/section/head.blade.php ENDPATH**/ ?>