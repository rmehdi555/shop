
<?php $__env->startSection('content'); ?>
    <div class="main-inner-banner">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="main-inner-banner-cont">
                        <div class="main-inner-banner-c-title">
                            <ul class="main-breadcrumb">
                                <li><a href="<?php echo e(route('web.home')); ?>"><?php echo e(__('web/public.home_page')); ?></a></li>
                                
                            </ul>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <section class="bu-inner-main">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="alert alert-info m-1">
                        <p class="p-1 text-justify">
                            جناب
                            <?php echo e($mosabegheMalekeZaman->name); ?> <?php echo e($mosabegheMalekeZaman->family); ?>

                            خوش آمدید .

                        </p>
                        <p class="p-1 text-justify">
                           سوالات را با دقت جواب دهید و پاسخ صحیح آنها بعد از اتمام زمان مسابقه در همین صفحه آزمون با وارد کردن مشخصات قابل مشاهده خواهد شد .
                        </p>
                        <p class="p-1 text-justify">
                            * تنها یک بار میتوانید دکمه ثبت نهایی را انتخاب کنید و قابل ویرایش نمیباشند لذا در پاسخ دادن به سوالات دقت نمایید .
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Start: Inner main -->


    <?php if($mosabegheMalekeZaman->status==0): ?>
    <?php endif; ?>
    <!-- Start: Inner main -->
    <section class="bu-inner-main">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="bu-inner-main-form">
                        <?php if(count($errors) > 0): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        <form class="form-horizontal" id="form-level-1-save" method="POST"
                              action="<?php echo e(route('web.mosabeghe.javab.test.save')); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="user_meli_number" value="<?php echo e($mosabegheMalekeZaman->meli_number); ?>">
                            <input type="hidden" name="user_mosabeghe_id" value="<?php echo e($mosabegheMalekeZaman->id); ?>">
                            <input type="hidden" name="nextM" value="<?php echo e($nextM); ?>">
                            <?php $i=1; ?>

                            <?php $__currentLoopData = $soals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <div class="row">
                                <div class="col-md-12 padding-top-15">
                                    <label class="col-md-12 col-sm-12 control-label" for="job"><?php echo e($i); ?> - <?php echo e($value->title); ?>

                                        <span class="required">*</span></label>
                                    <?php $__currentLoopData = $value->javabs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $valueJavabs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-md-12 col-sm-12">
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input" type="radio" name="javabs[<?php echo e($value->id); ?>]" id="" value="<?php echo e($valueJavabs->id); ?>" required>
                                                <label class="form-check-label p-2" for="inlineRadio1"><?php echo e($valueJavabs->title); ?></label>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                    <?php $i++; ?>

                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <br><br>

                            <div class="d-flex justify-content-center mb-2">

                                <div class="p-2 ">
                                    <button type="submit" class="btn btn-primary">ثبت نهایی پاسخ ها</button>
                                </div>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Start: Inner main -->





<?php $__env->stopSection(); ?>



<?php echo $__env->make('web.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Mr Rezaei\Desktop\noor\resources\views/web/pages/mosabeghe-javab-test.blade.php ENDPATH**/ ?>