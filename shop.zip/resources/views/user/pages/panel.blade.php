@extends('user.master')
@section('content')

    <div id="container">
        <div class="container">
            {{--<div class="row">--}}
                {{--<!-- Breadcrumb Start-->--}}
                {{--<ul class="breadcrumb">--}}
                    {{--<li itemscope itemtype="{{ route('web.home') }}"><a href="{{ route('web.home') }}"--}}
                                                                        {{--itemprop="url"><span--}}
                                    {{--itemprop="title"><i class="fa fa-home"></i></span></a></li>--}}
                    {{--<li itemscope itemtype="{{__('user/public.panel')}}"><a href="{{__('user/public.panel')}}"--}}
                                                                            {{--itemprop="url"><span--}}
                                    {{--itemprop="title">{{__('user/public.panel')}}</span></a>--}}
                    {{--</li>--}}
                {{--</ul>--}}
            {{--</div>--}}
            <!-- Breadcrumb End-->
            <div class="row">
                <!--Middle Part Start-->
                <div id="content" class="col-sm-9">
                    444
                </div>
            </div>
            <!--Middle Part End -->
@endsection