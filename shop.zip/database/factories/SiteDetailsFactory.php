<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\SiteDetails;
use Faker\Generator as Faker;

$factory->define(SiteDetails::class, function (Faker $faker) {
    return [
        //
    ];
});
