<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\slider;
use Faker\Generator as Faker;

$factory->define(slider::class, function (Faker $faker) {
    return [
        //
    ];
});
